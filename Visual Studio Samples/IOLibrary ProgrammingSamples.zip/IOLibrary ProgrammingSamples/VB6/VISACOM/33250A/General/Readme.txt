This example program use VISA COM
in Visual Basic 6.0

Demonstrates the use of:
 Modulation, Pulse, Sweeping, Burst, and Status checking.
 various uses of short/long form SCPI.
 enabling/disabling output BNCs.


To view results on Scope, set scope to:
     Channel 1: Output BNC, 50ohms, 50us/div, 200mV/div
     Channel 2: Sync BNC, 50us/div, 500mV/div, trigger on Channel 2


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
To use the Visual Basic Examples, you must first load the
Agilent VISA COM. 


