#define SCOPE_EXIT       1
#define SCOPE_READ_VOLT  2
#define SCOPE_GET_DATA   3
#define SCOPE_HEADER     4
#define SCOPE_PRINT      5

