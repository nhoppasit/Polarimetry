﻿Public Class frmColorTable

    Private Sub frmColorTable_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        LoadColorTable()
    End Sub

    Private Sub LoadColorTable()
        lvColorTable.Items.Clear()
        Dim LVI As ListViewItem
        LVI = New ListViewItem
        LVI.UseItemStyleForSubItems = False
        LVI.Text = "Reference"
        LVI.SubItems.Add("")
        LVI.SubItems.Add(frmMain.ReferenceColor.ToString)
        LVI.SubItems(1).BackColor = frmMain.ReferenceColor
        lvColorTable.Items.Add(LVI)
        For i As Integer = 0 To 19
            LVI = New ListViewItem
            LVI.UseItemStyleForSubItems = False
            LVI.Text = (i + 1).ToString
            LVI.SubItems.Add("")
            LVI.SubItems.Add(frmMain.ColorTable(i).ToString)
            LVI.SubItems(1).BackColor = frmMain.ColorTable(i)
            lvColorTable.Items.Add(LVI)
        Next
    End Sub

    Private Sub ApplyColorTable()
        For i As Integer = 0 To 19
            frmMain.ColorTable(i) = lvColorTable.Items(i).SubItems(1).BackColor
        Next
    End Sub

    Private Sub lvColorTable_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles lvColorTable.MouseDoubleClick
        Try
            Dim i As Integer = lvColorTable.SelectedIndices(0)
            Dim dlg As New ColorDialog
            dlg.Color = lvColorTable.SelectedItems(0).SubItems(1).BackColor
            dlg.ShowDialog()
            If i = 0 Then
                frmMain.ReferenceColor = dlg.Color
            Else
                frmMain.ColorTable(i - 1) = dlg.Color
            End If
            lvColorTable.SelectedItems(0).SubItems(1).BackColor = dlg.Color
            lvColorTable.SelectedItems(0).SubItems(2).Text = dlg.Color.ToString
        Catch ex As Exception
            'do nothing
        End Try
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Close()
    End Sub
End Class