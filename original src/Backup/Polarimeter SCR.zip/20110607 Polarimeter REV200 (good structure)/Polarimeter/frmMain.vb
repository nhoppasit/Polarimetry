﻿Imports System
Imports System.IO
Imports System.Text

Public Class frmMain

#Region "DECRALATION"

    'CONSTANTS
    Const StepFactor = 0.013325 'Deg/Step

    'Dynaplot objects
    Dim ReferenceCurve As DYNAPLOT3Lib.Curve
    Dim TreatmentCurve As DYNAPLOT3Lib.Curve
    Dim TreatmentMinMarker As DYNAPLOT3Lib.Marker
    Dim ReferenceMinMarker As DYNAPLOT3Lib.Marker

    'SCANING & Data
    Dim TheData As BaseDataControl
    Dim IsScanning As Boolean = False
    Dim CurrentPointIndex As Integer = 0
    Dim SpecificRotation As Double
    Dim NumberOfRepeatation As Integer
    Dim SelectedIndex As Integer

#End Region

#Region "DEVICES"

    Private DMM As Ivi.Visa.Interop.IFormattedIO488
    Private MMC As Ivi.Visa.Interop.IFormattedIO488

#End Region

#Region "Control Panel"
    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        'Add curve
        Dim x(0) As Double
        Dim y(0) As Double

        ResetDynaplot()

        PlotReferenceCurve()

        '----------------------------------------
        '1. Update buttons
        '----------------------------------------
        btnStart.Enabled = False
        btnStop.Enabled = True
        btnPause.Enabled = True

        '----------------------------------------
        '2. start Test loop of reading light intensity
        '----------------------------------------
        CurrentPointIndex = 0
        IsScanning = True
        DoScanLightIntensity()

    End Sub

    Private Sub btnStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStop.Click
        '----------------------------------------
        '1. stop Test loop of reading light intensity
        '----------------------------------------
        StopScanning()

        '----------------------------------------
        '2. Update buttons
        '----------------------------------------
        btnStart.Enabled = True
        btnStop.Enabled = False
        btnPause.Enabled = False
        btnPause.Text = "PAUSE"

    End Sub

    Private Sub btnPause_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPause.Click
        '----------------------------------------
        '1. pause/continue Test loop of reading light intensity
        '----------------------------------------
        If btnPause.Text = "PAUSE" Then
            DoPauseScanning()
        Else
            DoContinueScanning()
        End If

        '----------------------------------------
        '2. Update buttons
        '----------------------------------------
        btnStart.Enabled = False
        btnStop.Enabled = True
        btnPause.Enabled = True
        If btnPause.Text = "PAUSE" Then
            btnPause.Text = "CONTINUE"
        Else
            btnPause.Text = "PAUSE"
            DoScanLightIntensity()
        End If
    End Sub

#End Region

#Region "Scanning Procedure"
    Private Sub DoScanLightIntensity()
        If lvSummary.SelectedItems.Count <= 0 Then
            MsgBox("Invalid item index! Please select repeatation.", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly)
            btnStart.Enabled = True
            btnStop.Enabled = False
            btnPause.Enabled = False
            btnPause.Text = "PAUSE"
            Exit Sub
        End If
        Try
            '--------------------------------------------
            'get read conditions
            '--------------------------------------------
            Dim ThetaA As Double = CDbl(txtStart.Text)
            Dim ThetaB As Double = CDbl(txtStop.Text)
            Dim Delta As Double = CDbl(txtResolution.Text)

            '--------------------------------------------
            'initialize minimum finder
            '--------------------------------------------
            If SelectedIndex = 0 Then
                TheData.Reference.YAtMinimum = 99999999
            Else
                If TheData.IntensityData IsNot Nothing Then
                    If SelectedIndex <= TheData.IntensityData.Length Then
                        TheData.IntensityData(SelectedIndex - 1).YAtMinimum = 99999999
                    End If
                End If
            End If

            '----------------------------------------------------------------
            'REAL INTERFACE YES OR NOT (Theta,I)
            '----------------------------------------------------------------
            Dim CurrentLightIntensity As Double
            Dim StepNumber As Integer
            Dim MSG As String
            Dim CurrentTheta As Double = ThetaA + CurrentPointIndex * Delta
            'check demo mode
            If mnuOptionsDemomode.Checked = False Then
                '0.4 GOTO Theta A
                StepNumber = CInt(CurrentTheta / StepFactor) 'step
                MSG = "A:XP-" & StepNumber.ToString
                MMC.WriteString(MSG)
                '0.5 Read first
                DMM.WriteString("READ?")
                CurrentLightIntensity = DMM.ReadNumber
            Else 'IN DEMO MODE
                CurrentLightIntensity = Rnd() * 10 + Math.Sin(CurrentTheta * Math.PI / 180)
            End If

            '----------------------------------------------------------------
            'STORE DATA AND PLOT
            '----------------------------------------------------------------
            'Save to memory
            If SelectedIndex = 0 Then 'Blank
                TheData.PatchReference(CurrentPointIndex, CurrentTheta, CurrentLightIntensity)
                ReferenceCurve.UpdateData(TheData.Reference.X, TheData.Reference.Y, CurrentPointIndex + 1)
                ReferenceMinMarker.PositionX = TheData.Reference.XAtMinimum
                ReferenceMinMarker.PositionY = TheData.Reference.YAtMinimum
            Else 'Treatments
                TheData.PatchData(SelectedIndex - 1, CurrentPointIndex, CurrentTheta, CurrentLightIntensity)
                TreatmentCurve.UpdateData(TheData.IntensityData(SelectedIndex - 1).X, TheData.IntensityData(SelectedIndex - 1).Y, CurrentPointIndex + 1)
                TreatmentMinMarker.PositionX = TheData.IntensityData(SelectedIndex - 1).XAtMinimum
                TreatmentMinMarker.PositionY = TheData.IntensityData(SelectedIndex - 1).YAtMinimum
            End If


            '--------------------------------------------
            'MAIN READING LOOP (^0^)
            '--------------------------------------------
            While IsScanning

                Application.DoEvents()

                'Update current THETA
                CurrentTheta = ThetaA + CurrentPointIndex * Delta

                '--------------------------------------------
                'CHECK DEMO MODE
                '--------------------------------------------
                If mnuOptionsDemomode.Checked = False Then

                    '--------------------------------------------
                    'REAL INTERFACING
                    '--------------------------------------------
                    '1. Move polarizer 
                    StepNumber = CInt(CurrentTheta / StepFactor) 'step
                    MSG = "A:XP-" & StepNumber.ToString
                    MMC.WriteString(MSG)
                    '2. delay
                    Dim sw As New Stopwatch
                    sw.Start()
                    Do
                        'do nothing
                    Loop Until sw.ElapsedMilliseconds > 500 'ms
                    '3. Read light intensity
                    DMM.WriteString("READ?")
                    CurrentLightIntensity = DMM.ReadNumber

                Else

                    '--------------------------------------------
                    'DEMO MODE
                    '--------------------------------------------
                    'Delay.
                    Dim sw As New Stopwatch
                    sw.Start()
                    Do
                        'do nothing
                    Loop Until sw.ElapsedMilliseconds > 50 'ms
                    'Simulation
                    CurrentLightIntensity = Rnd() + Math.Cos(CurrentTheta * Math.PI / 180) + 2

                End If

                'Save to memory and update curve
                If SelectedIndex = 0 Then 'Blank
                    TheData.PatchReference(CurrentPointIndex, CurrentTheta, CurrentLightIntensity)
                    ReferenceCurve.UpdateData(TheData.Reference.X, TheData.Reference.Y, CurrentPointIndex + 1)
                    ReferenceMinMarker.PositionX = TheData.Reference.XAtMinimum
                    ReferenceMinMarker.PositionY = TheData.Reference.YAtMinimum
                Else 'Treatments
                    TheData.PatchData(SelectedIndex - 1, CurrentPointIndex, CurrentTheta, CurrentLightIntensity)
                    TreatmentCurve.UpdateData(TheData.IntensityData(SelectedIndex - 1).X, TheData.IntensityData(SelectedIndex - 1).Y, CurrentPointIndex + 1)
                    TreatmentMinMarker.PositionX = TheData.IntensityData(SelectedIndex - 1).XAtMinimum
                    TreatmentMinMarker.PositionY = TheData.IntensityData(SelectedIndex - 1).YAtMinimum
                End If

                'auto scale
                AxDynaPlot1.Axes.Y1Axis.Autoscale()

                'check stop condition!!!
                If ThetaB < CurrentTheta Then IsScanning = False
                '--------------------------------------------

                'next point
                CurrentPointIndex += 1

            End While
            '--------------------------------------------(^0^)

            'if stop update buttons to a new start
            If btnPause.Text <> "CONTINUE" Then
                btnStart.Enabled = True
                btnStop.Enabled = False
                btnPause.Enabled = False
                btnPause.Text = "PAUSE"
            Else 'if pause update buttons to continue
                btnStart.Enabled = False
                btnStop.Enabled = True
                btnPause.Enabled = True
            End If

        Catch ex As Exception

            MsgBox(ex.Message)

            '----------------------------------------
            '1. stop Test loop of reading light intensity
            '----------------------------------------
            StopScanning()

            '----------------------------------------
            '2. Update buttons
            '----------------------------------------
            btnStart.Enabled = True
            btnStop.Enabled = False
            btnPause.Enabled = False
            btnPause.Text = "PAUSE"

        End Try

    End Sub

    Private Sub StopScanning()
        IsScanning = False
    End Sub

    Private Sub DoPauseScanning()
        IsScanning = False
    End Sub

    Private Sub DoContinueScanning()
        IsScanning = True
    End Sub

#End Region

#Region "Menus"

#Region "File"

    Private Sub mnuFileNewMeasurement_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileNewMeasurement.Click
        NewMeasurement()
    End Sub

    Private Sub mnuFileLoadMC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub mnuFileSaveDataAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileSaveDataAs.Click

    End Sub

    Private Sub mnuFileSaveMC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub mnuSaveMCAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub mnuFileOpendata_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileOpendata.Click

    End Sub

    Private Sub mnuFileSaveData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileSaveData.Click

    End Sub

    Private Sub mnuFileQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileQuit.Click

    End Sub

#End Region

    Private Sub ConnectToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConnectToolStripMenuItem.Click

        Try
            '-------------------------------------------
            'CONNECT DMM
            '-------------------------------------------
            Dim mgr1 As Ivi.Visa.Interop.ResourceManager
            Dim DMMAddress As String
            DMMAddress = txtDMMAddress.Text
            mgr1 = New Ivi.Visa.Interop.ResourceManager
            DMM = New Ivi.Visa.Interop.FormattedIO488
            DMM.IO() = mgr1.Open(DMMAddress)
            DMM.IO.Timeout = 7000

            '-------------------------------------------
            'CONNECT MMC
            '-------------------------------------------
            Dim mgr2 As Ivi.Visa.Interop.ResourceManager
            Dim MMCAddress As String
            MMCAddress = txtMMCAddress.Text
            mgr2 = New Ivi.Visa.Interop.ResourceManager
            MMC = New Ivi.Visa.Interop.FormattedIO488
            MMC.IO() = mgr2.Open(MMCAddress)
            MMC.IO.Timeout = 7000

            MsgBox("Connect devices are successful.")

        Catch ex As Exception
            MsgBox("InitIO Error:" & vbCrLf & ex.Message)
        End Try

    End Sub

    Private Sub DisconnectToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisconnectToolStripMenuItem.Click
        Try

            DMM.IO.Close()
            DMM.IO = Nothing
            MMC.IO.Close()
            MMC.IO = Nothing
            MsgBox("Devices have been disconnected.")

        Catch ex As Exception
            MsgBox("IO Error: " & ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

#End Region

#Region "Form Event"

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        IsScanning = False
    End Sub

#End Region

#Region "PLOT"

    Private Sub ResetDynaplot()
        Dim x(0) As Double
        Dim y(0) As Double

        AxDynaPlot1.DataCurves.RemoveAll()
        AxDynaPlot1.Markers.RemoveAll()

        ReferenceCurve = AxDynaPlot1.DataCurves.Add("REF", x, y, 0, False).Curve
        ReferenceMinMarker = AxDynaPlot1.Markers.Add(0.0, 0.0, 0, DYNAPLOT3Lib.dpsMARKERTYPE.dpsMARKER_CIRCLE)

        TreatmentCurve = AxDynaPlot1.DataCurves.Add("TRT", x, y, 0, False).Curve
        TreatmentMinMarker = AxDynaPlot1.Markers.Add(0.0, 0.0, 0, DYNAPLOT3Lib.dpsMARKERTYPE.dpsMARKER_SQUARE)
    End Sub

    Private Sub PlotReferenceCurve()
        If TheData.Reference.X IsNot Nothing Then
            ReferenceCurve.UpdateData(TheData.Reference.X, TheData.Reference.Y, TheData.Reference.X.Length)
            ReferenceMinMarker.PositionX = TheData.Reference.XAtMinimum
            ReferenceMinMarker.PositionY = TheData.Reference.YAtMinimum
            lblMainStatus.Text = _
                "Theta(min) = " & _
                TheData.Reference.XAtMinimum.ToString("0.000000") & _
                " deg"
            AxDynaPlot1.Axes.Autoscale()
        End If
    End Sub

    Private Sub PlotSelectedTreatmentCurve()
        If TheData Is Nothing Then Exit Sub
        If TheData.IntensityData Is Nothing Then Exit Sub
        TreatmentCurve.UpdateData(TheData.IntensityData(SelectedIndex).X, _
                                  TheData.IntensityData(SelectedIndex).Y, _
                                  TheData.IntensityData(SelectedIndex).X.Length)
        TreatmentMinMarker.PositionX = TheData.IntensityData(SelectedIndex).XAtMinimum
        TreatmentMinMarker.PositionY = TheData.IntensityData(SelectedIndex).YAtMinimum
        lblMainStatus.Text = _
            "Theta(min) = " & _
            TheData.IntensityData(SelectedIndex).XAtMinimum.ToString("0.000000") & _
            " deg"
        AxDynaPlot1.Axes.Autoscale()
    End Sub

#End Region

#Region "Sub-Routine"

    Private Sub NewMeasurement()
        'load dialog
        Dim f As New frmNewMeasurement
        f.ShowDialog()

        'do update the job
        If f.Verify() = True Then

            'get information
            txtSampleName.Text = f.SampleName
            SpecificRotation = f.SpecificRotation
            NumberOfRepeatation = f.NumberOfRepeatation

            'update form
            txtSR.Text = SpecificRotation.ToString
            TheData = New BaseDataControl

            'clear
            lvSummary.Items.Clear()
            Dim lvi As ListViewItem

            'add ref.
            lvi = New ListViewItem
            lvi.Text = "Reference"
            lvi.SubItems.Add("-")
            lvi.SubItems.Add("-")
            lvSummary.Items.Add(lvi)

            'add repeats
            For i As Integer = 1 To NumberOfRepeatation
                lvi = New ListViewItem
                lvi.Text = "Repeat " & i.ToString
                lvi.SubItems.Add("-")
                lvi.SubItems.Add("-")
                lvSummary.Items.Add(lvi)
            Next

            gbMeasurement.Enabled = True
            gbSample.Enabled = True
            gbScanCondition.Enabled = True
        End If
    End Sub

#End Region

    Private Sub lvSummary_ItemSelectionChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.ListViewItemSelectionChangedEventArgs) Handles lvSummary.ItemSelectionChanged
        If lvSummary.SelectedIndices Is Nothing Then Exit Sub
        If lvSummary.SelectedIndices.Count <= 0 Then Exit Sub
        SelectedIndex = lvSummary.SelectedIndices(0)
    End Sub

End Class
