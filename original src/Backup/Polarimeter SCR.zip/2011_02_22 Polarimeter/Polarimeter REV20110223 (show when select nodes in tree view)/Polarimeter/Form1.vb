﻿Public Class Form1

#Region "DECRALATION"
    'Structure
    Structure strucData
        Dim X() As Double
        Dim Y() As Double
        Dim MinimizingAngle As Double
        Dim MinimumIntensity As Double
    End Structure
    Structure strucTreatment
        Dim Repreat() As strucData
    End Structure

    '******MAIN PRIMARY INFORMATION*************
    Dim Reference As strucTreatment
    Dim Treatments() As strucTreatment
    Dim ReferenceCurve As DYNAPLOT3Lib.Curve
    Dim TreatmentCurve As DYNAPLOT3Lib.Curve
    Dim TreatmentMinMarker As DYNAPLOT3Lib.Marker
    Dim ReferenceMinMarker As DYNAPLOT3Lib.Marker
    Dim Imin As Double
    Dim ThetaMin As Double
    '*******************************************

    'CONSTANTS
    Const StepFactor = 0.013325 'Deg/Step

    'SCAN PROCECURE
    Dim IsScanning As Boolean = False
    Dim CurrentPointIndex As Integer = 0

    'IDENTIFY TREATMENT AND SCAN
    Dim TreatmentIndex As Integer
    Dim ScanIndex As Integer

#End Region

#Region "DEVICES"

    Private DMM As Ivi.Visa.Interop.IFormattedIO488
    Private MMC As Ivi.Visa.Interop.IFormattedIO488

#End Region

#Region "Control Panel"
    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        'Add curve
        Dim x(0) As Double
        Dim y(0) As Double

        ResetDynaplot()

        PlotReferenceCurve()

        'SET UPPER LIMIT OF MINIMUM LIGHT INTENSITY
        Imin = 9999999

        '----------------------------------------
        '1. Update buttons
        '----------------------------------------
        btnStart.Enabled = False
        btnStop.Enabled = True
        btnPause.Enabled = True

        '----------------------------------------
        '2. start Test loop of reading light intensity
        '----------------------------------------
        CurrentPointIndex = 0
        IsScanning = True
        DoScanLightIntensity()

    End Sub

    Private Sub btnStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStop.Click
        '----------------------------------------
        '1. stop Test loop of reading light intensity
        '----------------------------------------
        StopScanning()

        '----------------------------------------
        '2. Update buttons
        '----------------------------------------
        btnStart.Enabled = True
        btnStop.Enabled = False
        btnPause.Enabled = False
        btnPause.Text = "PAUSE"

    End Sub

    Private Sub btnPause_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPause.Click
        '----------------------------------------
        '1. pause/continue Test loop of reading light intensity
        '----------------------------------------
        If btnPause.Text = "PAUSE" Then
            DoPauseScanning()
        Else
            DoContinueScanning()
        End If

        '----------------------------------------
        '2. Update buttons
        '----------------------------------------
        btnStart.Enabled = False
        btnStop.Enabled = True
        btnPause.Enabled = True
        If btnPause.Text = "PAUSE" Then
            btnPause.Text = "CONTINUE"
        Else
            btnPause.Text = "PAUSE"
            DoScanLightIntensity()
        End If
    End Sub

#End Region

#Region "Scanning Procedure"
    Private Sub DoScanLightIntensity()
        Try
            '--------------------------------------------
            'INITIALIZATION
            '--------------------------------------------
            '0.1 Get node id
            Dim i As Integer = TreatmentIndex - 1
            Dim j As Integer = ScanIndex - 1
            '0.2 Redimension Treatments
            If i = -1 Then 'Blank
                ReDim Preserve Reference.Repreat(0 To 0)
            Else
                'Treatments
                If Treatments Is Nothing Then 'Check null array
                    ReDim Preserve Treatments(0 To i)
                Else 'Not nuul array
                    If Treatments.Length - 1 < i Then 'Index correction
                        ReDim Preserve Treatments(0 To i)
                    End If
                End If
                'Each repreat in treatements(i)
                If Treatments(i).Repreat Is Nothing Then 'Check null array
                    ReDim Preserve Treatments(i).Repreat(0 To j)
                Else 'Not null
                    If Treatments(i).Repreat.Length - 1 < j Then 'Index correction
                        ReDim Preserve Treatments(i).Repreat(0 To j)
                    End If
                End If
            End If
            '0.3 Read conditions
            Dim ThetaA As Double = CDbl(txtStart.Text)
            Dim ThetaB As Double = CDbl(txtStop.Text)
            Dim Delta As Double = CDbl(txtResolution.Text)
            '----------------------------------------------------------------

            '----------------------------------------------------------------
            'REAL INTERFACE YES OR NOT (Theta,I)
            '----------------------------------------------------------------
            Dim CurrentLightIntensity As Double
            Dim StepNumber As Integer
            Dim MSG As String
            Dim CurrentTheta As Double = ThetaA + CurrentPointIndex * Delta
            'check demo mode
            If chkDemo.Checked = False Then
                '0.4 GOTO Theta A
                StepNumber = CInt(CurrentTheta / StepFactor) 'step
                MSG = "A:XP-" & StepNumber.ToString
                MMC.WriteString(MSG)
                '0.5 Read first
                DMM.WriteString("READ?")
                CurrentLightIntensity = DMM.ReadNumber
            Else 'IN DEMO MODE
                CurrentLightIntensity = Rnd() * 10
            End If
            '----------------------------------------------------------------

            '----------------------------------------------------------------
            'CHECK MINIMUM VALUE
            '----------------------------------------------------------------
            If CurrentLightIntensity < Imin Then
                Imin = CurrentLightIntensity
                ThetaMin = CurrentTheta
            Else
                'DO NOTHING
            End If
            '----------------------------------------------------------------

            '----------------------------------------------------------------
            'STORE DATA AND PLOT
            '----------------------------------------------------------------
            '0.6 Save to memory
            If i = -1 Then 'Blank
                Reference.Repreat(0).MinimizingAngle = ThetaMin
                Reference.Repreat(0).MinimumIntensity = Imin
                ReDim Preserve Reference.Repreat(0).X(0 To CurrentPointIndex)
                ReDim Preserve Reference.Repreat(0).Y(0 To CurrentPointIndex)
                Reference.Repreat(0).X(CurrentPointIndex) = CurrentTheta
                Reference.Repreat(0).Y(CurrentPointIndex) = CurrentLightIntensity
                ReferenceCurve.UpdateData(Reference.Repreat(0).X, Reference.Repreat(0).Y, CurrentPointIndex)
                ReferenceMinMarker.PositionX = Reference.Repreat(0).MinimizingAngle
                ReferenceMinMarker.PositionY = Reference.Repreat(0).MinimumIntensity
            Else 'Treatments
                Treatments(i).Repreat(j).MinimizingAngle = ThetaMin
                Treatments(i).Repreat(j).MinimumIntensity = Imin
                ReDim Preserve Treatments(i).Repreat(j).X(0 To CurrentPointIndex)
                ReDim Preserve Treatments(i).Repreat(j).Y(0 To CurrentPointIndex)
                Treatments(i).Repreat(j).X(CurrentPointIndex) = CurrentTheta
                Treatments(i).Repreat(j).Y(CurrentPointIndex) = CurrentLightIntensity
                TreatmentCurve.UpdateData(Treatments(i).Repreat(j).X, Treatments(i).Repreat(j).Y, CurrentPointIndex)
                TreatmentMinMarker.PositionX = Treatments(i).Repreat(j).MinimizingAngle
                TreatmentMinMarker.PositionY = Treatments(i).Repreat(j).MinimumIntensity
            End If
            '--------------------------------------------

            '--------------------------------------------
            'MAIN READING LOOP (^0^)
            '--------------------------------------------
            While IsScanning

                Application.DoEvents()

                '0. Update point index and current THETA
                '***Here can control TEHTA!
                CurrentPointIndex += 1

                CurrentTheta = ThetaA + CurrentPointIndex * Delta

                '--------------------------------------------
                'CHECK DEMO MODE
                '--------------------------------------------
                If chkDemo.Checked = False Then

                    '--------------------------------------------
                    'REAL INTERFACING
                    '--------------------------------------------
                    '1. Move polarizer 
                    StepNumber = CInt(CurrentTheta / StepFactor) 'step
                    MSG = "A:XP-" & StepNumber.ToString
                    MMC.WriteString(MSG)
                    '2. delay
                    Dim sw As New Stopwatch
                    sw.Start()
                    Do
                        'do nothing
                    Loop Until sw.ElapsedMilliseconds > 500 'ms
                    '3. Read light intensity
                    DMM.WriteString("READ?")
                    CurrentLightIntensity = DMM.ReadNumber
                    '--------------------------------------------
                Else

                    '--------------------------------------------
                    'DEMO MODE
                    '--------------------------------------------
                    '1. Do not move polarizer
                    '2. Delay.
                    '3. Do not read light intensity
                    '***But simulate the light intensity
                    Dim sw As New Stopwatch
                    sw.Start()
                    Do
                        'do nothing
                    Loop Until sw.ElapsedMilliseconds > 200 'ms
                    CurrentLightIntensity = Rnd() * 10
                    '--------------------------------------------

                End If

                '--------------------------------------------

                '----------------------------------------------------------------
                'CHECK MINIMUM VALUE
                '----------------------------------------------------------------
                If CurrentLightIntensity < Imin Then
                    Imin = CurrentLightIntensity
                    ThetaMin = CurrentTheta
                    lblMinimumValue.Text = "Theta min is " & ThetaMin.ToString & " deg."
                Else
                    'DO NOTHING
                End If
                '----------------------------------------------------------------

                '--------------------------------------------
                'FINALIZATION
                '--------------------------------------------
                '4. Save to memory and update curve
                If i = -1 Then 'Blank
                    Reference.Repreat(0).MinimizingAngle = ThetaMin
                    Reference.Repreat(0).MinimumIntensity = Imin
                    ReDim Preserve Reference.Repreat(0).X(0 To CurrentPointIndex)
                    ReDim Preserve Reference.Repreat(0).Y(0 To CurrentPointIndex)
                    Reference.Repreat(0).X(CurrentPointIndex) = CurrentTheta
                    Reference.Repreat(0).Y(CurrentPointIndex) = CurrentLightIntensity
                    ReferenceCurve.UpdateData(Reference.Repreat(0).X, Reference.Repreat(0).Y, CurrentPointIndex)
                    ReferenceMinMarker.PositionX = Reference.Repreat(0).MinimizingAngle
                    ReferenceMinMarker.PositionY = Reference.Repreat(0).MinimumIntensity
                Else 'Treatments
                    Treatments(i).Repreat(j).MinimizingAngle = ThetaMin
                    Treatments(i).Repreat(j).MinimumIntensity = Imin
                    ReDim Preserve Treatments(i).Repreat(j).X(0 To CurrentPointIndex)
                    ReDim Preserve Treatments(i).Repreat(j).Y(0 To CurrentPointIndex)
                    Treatments(i).Repreat(j).X(CurrentPointIndex) = CurrentTheta
                    Treatments(i).Repreat(j).Y(CurrentPointIndex) = CurrentLightIntensity
                    TreatmentCurve.UpdateData(Treatments(i).Repreat(j).X, Treatments(i).Repreat(j).Y, CurrentPointIndex)
                    TreatmentMinMarker.PositionX = Treatments(i).Repreat(j).MinimizingAngle
                    TreatmentMinMarker.PositionY = Treatments(i).Repreat(j).MinimumIntensity
                End If
                AxDynaPlot1.Axes.Autoscale()
                '5. check stop condition
                If ThetaB < CurrentTheta Then IsScanning = False
                '--------------------------------------------


            End While
            '--------------------------------------------(^0^)

            'if stop update buttons to a new start
            If btnPause.Text <> "CONTINUE" Then
                btnStart.Enabled = True
                btnStop.Enabled = False
                btnPause.Enabled = False
                btnPause.Text = "PAUSE"
            Else 'if pause update buttons to continue
                btnStart.Enabled = False
                btnStop.Enabled = True
                btnPause.Enabled = True
            End If

        Catch ex As Exception

            MsgBox(ex.Message)

            '----------------------------------------
            '1. stop Test loop of reading light intensity
            '----------------------------------------
            StopScanning()

            '----------------------------------------
            '2. Update buttons
            '----------------------------------------
            btnStart.Enabled = True
            btnStop.Enabled = False
            btnPause.Enabled = False
            btnPause.Text = "PAUSE"

        End Try

    End Sub

    Private Sub StopScanning()
        IsScanning = False
    End Sub

    Private Sub DoPauseScanning()
        IsScanning = False
    End Sub

    Private Sub DoContinueScanning()
        IsScanning = True
    End Sub

#End Region

#Region "Menus"

    Private Sub ConnectToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConnectToolStripMenuItem.Click

        Try
            '-------------------------------------------
            'CONNECT DMM
            '-------------------------------------------
            Dim mgr1 As Ivi.Visa.Interop.ResourceManager
            Dim DMMAddress As String
            DMMAddress = txtDMMAddress.Text
            mgr1 = New Ivi.Visa.Interop.ResourceManager
            DMM = New Ivi.Visa.Interop.FormattedIO488
            DMM.IO() = mgr1.Open(DMMAddress)
            DMM.IO.Timeout = 7000

            '-------------------------------------------
            'CONNECT MMC
            '-------------------------------------------
            Dim mgr2 As Ivi.Visa.Interop.ResourceManager
            Dim MMCAddress As String
            MMCAddress = txtMMCAddress.Text
            mgr2 = New Ivi.Visa.Interop.ResourceManager
            MMC = New Ivi.Visa.Interop.FormattedIO488
            MMC.IO() = mgr2.Open(MMCAddress)
            MMC.IO.Timeout = 7000

            MsgBox("Connect devices are successful.")

        Catch ex As Exception
            MsgBox("InitIO Error:" & vbCrLf & ex.Message)
        End Try

    End Sub

    Private Sub DisconnectToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisconnectToolStripMenuItem.Click
        Try

            DMM.IO.Close()
            DMM.IO = Nothing
            MMC.IO.Close()
            MMC.IO = Nothing
            MsgBox("Devices have been disconnected.")

        Catch ex As Exception
            MsgBox("IO Error: " & ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

#End Region

#Region "Form Event"

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        IsScanning = False
    End Sub

#End Region

#Region "Tree view control panel"

    Private Sub btnResetTreatment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnResetTreatment.Click
        tvTreaments.Nodes.Clear()
        tvTreaments.Nodes.Add("R", "Reference")
        Dim NODE As TreeNode = tvTreaments.Nodes.Add("T1", "1.0 mg/l")
        NODE.Nodes.Add("S1", "SCAN 1")
    End Sub

    Private Sub tvTreaments_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvTreaments.AfterSelect
        Try
            If tvTreaments.SelectedNode.Parent Is Nothing Then
                If tvTreaments.SelectedNode.Index = 0 Then
                    TreatmentIndex = 0
                    ScanIndex = 0
                    lblSelectedNode.Text = "Reference"
                    'Show reference only
                    ResetDynaplot()
                    PlotReferenceCurve()
                Else
                    TreatmentIndex = tvTreaments.SelectedNode.Index
                    ScanIndex = 0
                End If
            Else
                If tvTreaments.SelectedNode.Parent IsNot Nothing Then
                    TreatmentIndex = tvTreaments.SelectedNode.Parent.Index
                    ScanIndex = tvTreaments.SelectedNode.Index + 1
                    Dim trtNODE As TreeNode = tvTreaments.Nodes(TreatmentIndex)
                    Dim scanNODE As TreeNode = trtNODE.Nodes(ScanIndex - 1)
                    lblSelectedNode.Text = trtNODE.Text & ", scan : " & scanNODE.Text
                    'Show Treatment Graph of (i,j) with reference
                    ResetDynaplot()
                    PlotReferenceCurve()
                    PlotSelectedTreatmentCurve()
                End If
            End If
        Catch ex As Exception
            'do nothing
        End Try
    End Sub

    Private Sub btnRemoveScan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemoveScan.Click
        If TreatmentIndex > 0 And ScanIndex > 0 Then
            'Here this is a treatment.
            Dim NODE As TreeNode = tvTreaments.Nodes(TreatmentIndex)
            NODE.Nodes(ScanIndex - 1).Remove()
        Else
            'This is not the treatment.
            MsgBox("Please select treatment and scan to remove the scan.")
        End If
    End Sub

    Private Sub btnAddScan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddScan.Click
        If TreatmentIndex <= 0 Then
            'This is not the treatment.
            MsgBox("Please select treatment to add a new scan.")
        Else
            'Here this is a treatment.
            Dim NODE As TreeNode = tvTreaments.Nodes(TreatmentIndex)
            Dim OldScanCount As Integer = NODE.Nodes.Count
            NODE.Nodes.Add("SCAN " & (OldScanCount + 1).ToString)
        End If
    End Sub

    Private Sub btnAddConc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddConc.Click
        Dim str As String = InputBox("Please enter the concentration:", "Input Concentration", "2.0 g/ml")
        If str <> "" Then
            Dim NODE As TreeNode = tvTreaments.Nodes.Add(str, str)
            NODE.Nodes.Add("SCAN 1")
        End If
    End Sub

    Private Sub btnRemoveConc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemoveConc.Click
        If TreatmentIndex <= 0 Then
            MsgBox("Please select treatment to be removed.")
        Else
            Dim trtNODE As TreeNode = tvTreaments.Nodes(TreatmentIndex)
            If MsgBox("Are you sure?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                trtNODE.Remove()
            End If
        End If
    End Sub

#End Region

    Private Sub ResetDynaplot()
        Dim x(0) As Double
        Dim y(0) As Double

        AxDynaPlot1.DataCurves.RemoveAll()
        AxDynaPlot1.Markers.RemoveAll()

        ReferenceCurve = AxDynaPlot1.DataCurves.Add("REF", x, y, 0, False).Curve
        ReferenceMinMarker = AxDynaPlot1.Markers.Add(0.0, 0.0, 0, DYNAPLOT3Lib.dpsMARKERTYPE.dpsMARKER_CIRCLE)

        TreatmentCurve = AxDynaPlot1.DataCurves.Add("TRT", x, y, 0, False).Curve
        TreatmentMinMarker = AxDynaPlot1.Markers.Add(0.0, 0.0, 0, DYNAPLOT3Lib.dpsMARKERTYPE.dpsMARKER_SQUARE)
    End Sub

    Private Sub PlotReferenceCurve()
        If Reference.Repreat IsNot Nothing Then
            ReferenceCurve.UpdateData(Reference.Repreat(0).X, Reference.Repreat(0).Y, Reference.Repreat(0).X.Length)
            ReferenceMinMarker.PositionX = Reference.Repreat(0).MinimizingAngle
            ReferenceMinMarker.PositionY = Reference.Repreat(0).MinimumIntensity
            AxDynaPlot1.Axes.Autoscale()
        End If
    End Sub

    Private Sub PlotSelectedTreatmentCurve()
        If Treatments Is Nothing Then
            Exit Sub
        Else
            If Treatments(TreatmentIndex - 1).Repreat IsNot Nothing Then
                TreatmentCurve.UpdateData(Treatments(TreatmentIndex - 1).Repreat(ScanIndex - 1).X, _
                                          Treatments(TreatmentIndex - 1).Repreat(ScanIndex - 1).Y, _
                                          Treatments(TreatmentIndex - 1).Repreat(ScanIndex - 1).X.Length)
                TreatmentMinMarker.PositionX = Treatments(TreatmentIndex - 1).Repreat(ScanIndex - 1).MinimizingAngle
                TreatmentMinMarker.PositionY = Treatments(TreatmentIndex - 1).Repreat(ScanIndex - 1).MinimumIntensity
                AxDynaPlot1.Axes.Autoscale()
            End If
        End If
    End Sub

End Class
