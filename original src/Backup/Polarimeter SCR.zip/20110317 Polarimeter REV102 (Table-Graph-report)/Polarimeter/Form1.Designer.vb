﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim TreeNode26 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Reference")
        Dim TreeNode27 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Scan 1")
        Dim TreeNode28 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Scan 2")
        Dim TreeNode29 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Scan 3")
        Dim TreeNode30 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("0.1 g/ml", New System.Windows.Forms.TreeNode() {TreeNode27, TreeNode28, TreeNode29})
        Dim TreeNode31 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Scan 1")
        Dim TreeNode32 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Scan 2")
        Dim TreeNode33 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Scan 3")
        Dim TreeNode34 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("0.15 g/ml", New System.Windows.Forms.TreeNode() {TreeNode31, TreeNode32, TreeNode33})
        Dim TreeNode35 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Scan 1")
        Dim TreeNode36 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Scan 2")
        Dim TreeNode37 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Scan 3")
        Dim TreeNode38 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("0.20 g/ml", New System.Windows.Forms.TreeNode() {TreeNode35, TreeNode36, TreeNode37})
        Dim TreeNode39 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Scan 1")
        Dim TreeNode40 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Scan 2")
        Dim TreeNode41 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Scan 3")
        Dim TreeNode42 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("0.25 g/ml", New System.Windows.Forms.TreeNode() {TreeNode39, TreeNode40, TreeNode41})
        Dim TreeNode43 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Scan 1")
        Dim TreeNode44 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Scan 2")
        Dim TreeNode45 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Scan 3")
        Dim TreeNode46 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("0.30 g/ml", New System.Windows.Forms.TreeNode() {TreeNode43, TreeNode44, TreeNode45})
        Dim TreeNode47 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Scan 1")
        Dim TreeNode48 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Scan 2")
        Dim TreeNode49 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Scan 3")
        Dim TreeNode50 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("0.35 g/ml", New System.Windows.Forms.TreeNode() {TreeNode47, TreeNode48, TreeNode49})
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.FToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OpenDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SaveDataToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DevicesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ConnectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DisconnectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.ConfigAddressToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.txtDMMAddress = New System.Windows.Forms.ToolStripTextBox
        Me.MMC2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.txtMMCAddress = New System.Windows.Forms.ToolStripTextBox
        Me.ScanIntensityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.PauseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ContinueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.lblSelectedNode = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.btnResetTreatment = New System.Windows.Forms.Button
        Me.btnAddScan = New System.Windows.Forms.Button
        Me.btnRemoveConc = New System.Windows.Forms.Button
        Me.tvTreaments = New System.Windows.Forms.TreeView
        Me.btnRemoveScan = New System.Windows.Forms.Button
        Me.btnAddConc = New System.Windows.Forms.Button
        Me.lblMinimumValue = New System.Windows.Forms.Label
        Me.chkDemo = New System.Windows.Forms.CheckBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtStop = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtStart = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtResolution = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.btnPause = New System.Windows.Forms.Button
        Me.btnStop = New System.Windows.Forms.Button
        Me.btnStart = New System.Windows.Forms.Button
        Me.AxDynaPlot1 = New AxDYNAPLOT3Lib.AxDynaPlot
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.Label9 = New System.Windows.Forms.Label
        Me.lblReport = New System.Windows.Forms.Label
        Me.btnCalculate = New System.Windows.Forms.Button
        Me.btnUpdateTable = New System.Windows.Forms.Button
        Me.ListView1 = New System.Windows.Forms.ListView
        Me.ColumnHeader1 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader2 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader3 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader4 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader6 = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader5 = New System.Windows.Forms.ColumnHeader
        Me.AxDynaPlot2 = New AxDYNAPLOT3Lib.AxDynaPlot
        Me.MenuStrip1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.AxDynaPlot1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.AxDynaPlot2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FToolStripMenuItem, Me.DevicesToolStripMenuItem, Me.ScanIntensityToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(945, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FToolStripMenuItem
        '
        Me.FToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenDataToolStripMenuItem, Me.SaveDataToolStripMenuItem, Me.ToolStripSeparator1, Me.ExitToolStripMenuItem})
        Me.FToolStripMenuItem.Name = "FToolStripMenuItem"
        Me.FToolStripMenuItem.Size = New System.Drawing.Size(35, 20)
        Me.FToolStripMenuItem.Text = "File"
        '
        'OpenDataToolStripMenuItem
        '
        Me.OpenDataToolStripMenuItem.Name = "OpenDataToolStripMenuItem"
        Me.OpenDataToolStripMenuItem.Size = New System.Drawing.Size(125, 22)
        Me.OpenDataToolStripMenuItem.Text = "Open data"
        '
        'SaveDataToolStripMenuItem
        '
        Me.SaveDataToolStripMenuItem.Name = "SaveDataToolStripMenuItem"
        Me.SaveDataToolStripMenuItem.Size = New System.Drawing.Size(125, 22)
        Me.SaveDataToolStripMenuItem.Text = "Save data"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(122, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(125, 22)
        Me.ExitToolStripMenuItem.Text = "Quit"
        '
        'DevicesToolStripMenuItem
        '
        Me.DevicesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ConnectToolStripMenuItem, Me.DisconnectToolStripMenuItem, Me.ToolStripSeparator2, Me.ConfigAddressToolStripMenuItem, Me.MMC2ToolStripMenuItem})
        Me.DevicesToolStripMenuItem.Name = "DevicesToolStripMenuItem"
        Me.DevicesToolStripMenuItem.Size = New System.Drawing.Size(56, 20)
        Me.DevicesToolStripMenuItem.Text = "Devices"
        '
        'ConnectToolStripMenuItem
        '
        Me.ConnectToolStripMenuItem.Name = "ConnectToolStripMenuItem"
        Me.ConnectToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.ConnectToolStripMenuItem.Text = "Connect"
        '
        'DisconnectToolStripMenuItem
        '
        Me.DisconnectToolStripMenuItem.Name = "DisconnectToolStripMenuItem"
        Me.DisconnectToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.DisconnectToolStripMenuItem.Text = "Disconnect"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(134, 6)
        '
        'ConfigAddressToolStripMenuItem
        '
        Me.ConfigAddressToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.txtDMMAddress})
        Me.ConfigAddressToolStripMenuItem.Name = "ConfigAddressToolStripMenuItem"
        Me.ConfigAddressToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.ConfigAddressToolStripMenuItem.Text = "DMM 34401A"
        '
        'txtDMMAddress
        '
        Me.txtDMMAddress.Name = "txtDMMAddress"
        Me.txtDMMAddress.Size = New System.Drawing.Size(100, 21)
        Me.txtDMMAddress.Text = "GPIB0::26::INSTR"
        '
        'MMC2ToolStripMenuItem
        '
        Me.MMC2ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.txtMMCAddress})
        Me.MMC2ToolStripMenuItem.Name = "MMC2ToolStripMenuItem"
        Me.MMC2ToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.MMC2ToolStripMenuItem.Text = "MMC-2"
        '
        'txtMMCAddress
        '
        Me.txtMMCAddress.Name = "txtMMCAddress"
        Me.txtMMCAddress.Size = New System.Drawing.Size(100, 21)
        Me.txtMMCAddress.Text = "GPIB0::7::INSTR"
        '
        'ScanIntensityToolStripMenuItem
        '
        Me.ScanIntensityToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StartToolStripMenuItem, Me.StopToolStripMenuItem, Me.ToolStripSeparator3, Me.PauseToolStripMenuItem, Me.ContinueToolStripMenuItem})
        Me.ScanIntensityToolStripMenuItem.Name = "ScanIntensityToolStripMenuItem"
        Me.ScanIntensityToolStripMenuItem.Size = New System.Drawing.Size(88, 20)
        Me.ScanIntensityToolStripMenuItem.Text = "Scan Intensity"
        '
        'StartToolStripMenuItem
        '
        Me.StartToolStripMenuItem.Name = "StartToolStripMenuItem"
        Me.StartToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.StartToolStripMenuItem.Text = "Start"
        '
        'StopToolStripMenuItem
        '
        Me.StopToolStripMenuItem.Name = "StopToolStripMenuItem"
        Me.StopToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.StopToolStripMenuItem.Text = "Stop"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(114, 6)
        '
        'PauseToolStripMenuItem
        '
        Me.PauseToolStripMenuItem.Name = "PauseToolStripMenuItem"
        Me.PauseToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.PauseToolStripMenuItem.Text = "Pause"
        '
        'ContinueToolStripMenuItem
        '
        Me.ContinueToolStripMenuItem.Name = "ContinueToolStripMenuItem"
        Me.ContinueToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.ContinueToolStripMenuItem.Text = "Continue"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(146, 22)
        Me.AboutToolStripMenuItem.Text = "About program"
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(12, 27)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(921, 441)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.lblMinimumValue)
        Me.TabPage1.Controls.Add(Me.chkDemo)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Controls.Add(Me.btnPause)
        Me.TabPage1.Controls.Add(Me.btnStop)
        Me.TabPage1.Controls.Add(Me.btnStart)
        Me.TabPage1.Controls.Add(Me.AxDynaPlot1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(913, 415)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "STEP 1 : Scan Intensity"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.lblSelectedNode)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.btnResetTreatment)
        Me.GroupBox2.Controls.Add(Me.btnAddScan)
        Me.GroupBox2.Controls.Add(Me.btnRemoveConc)
        Me.GroupBox2.Controls.Add(Me.tvTreaments)
        Me.GroupBox2.Controls.Add(Me.btnRemoveScan)
        Me.GroupBox2.Controls.Add(Me.btnAddConc)
        Me.GroupBox2.Location = New System.Drawing.Point(6, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(320, 196)
        Me.GroupBox2.TabIndex = 25
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Treatments"
        '
        'lblSelectedNode
        '
        Me.lblSelectedNode.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblSelectedNode.AutoSize = True
        Me.lblSelectedNode.Location = New System.Drawing.Point(94, 175)
        Me.lblSelectedNode.Name = "lblSelectedNode"
        Me.lblSelectedNode.Size = New System.Drawing.Size(16, 13)
        Me.lblSelectedNode.TabIndex = 24
        Me.lblSelectedNode.Text = "..."
        '
        'Label7
        '
        Me.Label7.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(8, 175)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(81, 13)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "Selected Node:"
        '
        'btnResetTreatment
        '
        Me.btnResetTreatment.Location = New System.Drawing.Point(86, 53)
        Me.btnResetTreatment.Name = "btnResetTreatment"
        Me.btnResetTreatment.Size = New System.Drawing.Size(150, 29)
        Me.btnResetTreatment.TabIndex = 22
        Me.btnResetTreatment.Text = "Reset Treatment"
        Me.btnResetTreatment.UseVisualStyleBackColor = True
        '
        'btnAddScan
        '
        Me.btnAddScan.BackColor = System.Drawing.Color.Transparent
        Me.btnAddScan.Location = New System.Drawing.Point(164, 16)
        Me.btnAddScan.Name = "btnAddScan"
        Me.btnAddScan.Size = New System.Drawing.Size(72, 29)
        Me.btnAddScan.TabIndex = 6
        Me.btnAddScan.Text = "+Scan."
        Me.btnAddScan.UseVisualStyleBackColor = False
        '
        'btnRemoveConc
        '
        Me.btnRemoveConc.BackColor = System.Drawing.Color.Transparent
        Me.btnRemoveConc.Location = New System.Drawing.Point(86, 16)
        Me.btnRemoveConc.Name = "btnRemoveConc"
        Me.btnRemoveConc.Size = New System.Drawing.Size(72, 29)
        Me.btnRemoveConc.TabIndex = 5
        Me.btnRemoveConc.Text = "-Conc."
        Me.btnRemoveConc.UseVisualStyleBackColor = False
        '
        'tvTreaments
        '
        Me.tvTreaments.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.tvTreaments.Location = New System.Drawing.Point(6, 88)
        Me.tvTreaments.Name = "tvTreaments"
        TreeNode26.Name = "Node0"
        TreeNode26.Text = "Reference"
        TreeNode27.Name = "Node2"
        TreeNode27.Text = "Scan 1"
        TreeNode28.Name = "Node3"
        TreeNode28.Text = "Scan 2"
        TreeNode29.Name = "Node4"
        TreeNode29.Text = "Scan 3"
        TreeNode30.Name = "Node0"
        TreeNode30.Tag = "0.1"
        TreeNode30.Text = "0.1 g/ml"
        TreeNode31.Name = "Node6"
        TreeNode31.Text = "Scan 1"
        TreeNode32.Name = "Node7"
        TreeNode32.Text = "Scan 2"
        TreeNode33.Name = "Node8"
        TreeNode33.Text = "Scan 3"
        TreeNode34.Name = "Node1"
        TreeNode34.Tag = "0.15"
        TreeNode34.Text = "0.15 g/ml"
        TreeNode35.Name = "Node10"
        TreeNode35.Text = "Scan 1"
        TreeNode36.Name = "Node11"
        TreeNode36.Text = "Scan 2"
        TreeNode37.Name = "Node12"
        TreeNode37.Text = "Scan 3"
        TreeNode38.Name = "Node9"
        TreeNode38.Tag = "0.2"
        TreeNode38.Text = "0.20 g/ml"
        TreeNode39.Name = "Node14"
        TreeNode39.Text = "Scan 1"
        TreeNode40.Name = "Node15"
        TreeNode40.Text = "Scan 2"
        TreeNode41.Name = "Node16"
        TreeNode41.Text = "Scan 3"
        TreeNode42.Name = "Node13"
        TreeNode42.Tag = "0.25"
        TreeNode42.Text = "0.25 g/ml"
        TreeNode43.Name = "Node18"
        TreeNode43.Text = "Scan 1"
        TreeNode44.Name = "Node19"
        TreeNode44.Text = "Scan 2"
        TreeNode45.Name = "Node20"
        TreeNode45.Text = "Scan 3"
        TreeNode46.Name = "Node17"
        TreeNode46.Tag = "0.3"
        TreeNode46.Text = "0.30 g/ml"
        TreeNode47.Name = "Node22"
        TreeNode47.Text = "Scan 1"
        TreeNode48.Name = "Node23"
        TreeNode48.Text = "Scan 2"
        TreeNode49.Name = "Node24"
        TreeNode49.Text = "Scan 3"
        TreeNode50.Name = "Node21"
        TreeNode50.Tag = "0.35"
        TreeNode50.Text = "0.35 g/ml"
        Me.tvTreaments.Nodes.AddRange(New System.Windows.Forms.TreeNode() {TreeNode26, TreeNode30, TreeNode34, TreeNode38, TreeNode42, TreeNode46, TreeNode50})
        Me.tvTreaments.Size = New System.Drawing.Size(300, 84)
        Me.tvTreaments.TabIndex = 2
        '
        'btnRemoveScan
        '
        Me.btnRemoveScan.BackColor = System.Drawing.Color.Transparent
        Me.btnRemoveScan.Location = New System.Drawing.Point(242, 16)
        Me.btnRemoveScan.Name = "btnRemoveScan"
        Me.btnRemoveScan.Size = New System.Drawing.Size(72, 29)
        Me.btnRemoveScan.TabIndex = 7
        Me.btnRemoveScan.Text = "-Scan."
        Me.btnRemoveScan.UseVisualStyleBackColor = False
        '
        'btnAddConc
        '
        Me.btnAddConc.BackColor = System.Drawing.Color.Transparent
        Me.btnAddConc.Location = New System.Drawing.Point(3, 16)
        Me.btnAddConc.Name = "btnAddConc"
        Me.btnAddConc.Size = New System.Drawing.Size(72, 29)
        Me.btnAddConc.TabIndex = 1
        Me.btnAddConc.Text = "+Conc."
        Me.btnAddConc.UseVisualStyleBackColor = False
        '
        'lblMinimumValue
        '
        Me.lblMinimumValue.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblMinimumValue.AutoSize = True
        Me.lblMinimumValue.Location = New System.Drawing.Point(164, 209)
        Me.lblMinimumValue.Name = "lblMinimumValue"
        Me.lblMinimumValue.Size = New System.Drawing.Size(78, 13)
        Me.lblMinimumValue.TabIndex = 21
        Me.lblMinimumValue.Text = "Minimum Angle"
        '
        'chkDemo
        '
        Me.chkDemo.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.chkDemo.AutoSize = True
        Me.chkDemo.Checked = True
        Me.chkDemo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkDemo.Location = New System.Drawing.Point(14, 205)
        Me.chkDemo.Name = "chkDemo"
        Me.chkDemo.Size = New System.Drawing.Size(84, 17)
        Me.chkDemo.TabIndex = 20
        Me.chkDemo.Text = "Demo Mode"
        Me.chkDemo.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.txtStop)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtStart)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtResolution)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(14, 228)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(300, 107)
        Me.GroupBox1.TabIndex = 13
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Scan conditions"
        '
        'txtStop
        '
        Me.txtStop.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtStop.Location = New System.Drawing.Point(89, 45)
        Me.txtStop.Name = "txtStop"
        Me.txtStop.Size = New System.Drawing.Size(119, 20)
        Me.txtStop.TabIndex = 12
        Me.txtStop.Text = "360"
        Me.txtStop.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(54, 52)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(29, 13)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Stop"
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(214, 48)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(28, 13)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "deg."
        '
        'txtStart
        '
        Me.txtStart.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtStart.Location = New System.Drawing.Point(89, 19)
        Me.txtStart.Name = "txtStart"
        Me.txtStart.Size = New System.Drawing.Size(119, 20)
        Me.txtStart.TabIndex = 9
        Me.txtStart.Text = "0"
        Me.txtStart.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(54, 26)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 13)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Start"
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(214, 22)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(28, 13)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "deg."
        '
        'txtResolution
        '
        Me.txtResolution.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.txtResolution.Location = New System.Drawing.Point(89, 71)
        Me.txtResolution.Name = "txtResolution"
        Me.txtResolution.Size = New System.Drawing.Size(119, 20)
        Me.txtResolution.TabIndex = 3
        Me.txtResolution.Text = "2.0"
        Me.txtResolution.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(26, 78)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Resolution"
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(214, 74)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(28, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "deg."
        '
        'btnPause
        '
        Me.btnPause.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPause.BackColor = System.Drawing.Color.Gold
        Me.btnPause.Enabled = False
        Me.btnPause.Location = New System.Drawing.Point(231, 341)
        Me.btnPause.Name = "btnPause"
        Me.btnPause.Size = New System.Drawing.Size(83, 68)
        Me.btnPause.TabIndex = 11
        Me.btnPause.Text = "PAUSE"
        Me.btnPause.UseVisualStyleBackColor = False
        '
        'btnStop
        '
        Me.btnStop.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnStop.BackColor = System.Drawing.Color.Red
        Me.btnStop.Enabled = False
        Me.btnStop.Location = New System.Drawing.Point(120, 341)
        Me.btnStop.Name = "btnStop"
        Me.btnStop.Size = New System.Drawing.Size(83, 68)
        Me.btnStop.TabIndex = 10
        Me.btnStop.Text = "STOP"
        Me.btnStop.UseVisualStyleBackColor = False
        '
        'btnStart
        '
        Me.btnStart.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnStart.BackColor = System.Drawing.Color.Green
        Me.btnStart.Location = New System.Drawing.Point(6, 341)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(83, 68)
        Me.btnStart.TabIndex = 9
        Me.btnStart.Text = "START"
        Me.btnStart.UseVisualStyleBackColor = False
        '
        'AxDynaPlot1
        '
        Me.AxDynaPlot1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.AxDynaPlot1.Location = New System.Drawing.Point(332, 6)
        Me.AxDynaPlot1.Name = "AxDynaPlot1"
        Me.AxDynaPlot1.OcxState = CType(resources.GetObject("AxDynaPlot1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxDynaPlot1.Size = New System.Drawing.Size(569, 403)
        Me.AxDynaPlot1.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label9)
        Me.TabPage2.Controls.Add(Me.lblReport)
        Me.TabPage2.Controls.Add(Me.btnCalculate)
        Me.TabPage2.Controls.Add(Me.btnUpdateTable)
        Me.TabPage2.Controls.Add(Me.ListView1)
        Me.TabPage2.Controls.Add(Me.AxDynaPlot2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(913, 415)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "STEP 2 : Calculate and Plot Concentration"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(307, 24)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(42, 13)
        Me.Label9.TabIndex = 5
        Me.Label9.Text = "Report:"
        '
        'lblReport
        '
        Me.lblReport.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblReport.Location = New System.Drawing.Point(310, 42)
        Me.lblReport.Name = "lblReport"
        Me.lblReport.Size = New System.Drawing.Size(210, 41)
        Me.lblReport.TabIndex = 4
        Me.lblReport.Text = "-"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(155, 42)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(129, 31)
        Me.btnCalculate.TabIndex = 3
        Me.btnCalculate.Text = "Calculate/Report"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnUpdateTable
        '
        Me.btnUpdateTable.Location = New System.Drawing.Point(23, 42)
        Me.btnUpdateTable.Name = "btnUpdateTable"
        Me.btnUpdateTable.Size = New System.Drawing.Size(115, 31)
        Me.btnUpdateTable.TabIndex = 2
        Me.btnUpdateTable.Text = "Update Table"
        Me.btnUpdateTable.UseVisualStyleBackColor = True
        '
        'ListView1
        '
        Me.ListView1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4, Me.ColumnHeader6, Me.ColumnHeader5})
        Me.ListView1.GridLines = True
        Me.ListView1.Location = New System.Drawing.Point(14, 96)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(507, 278)
        Me.ListView1.TabIndex = 1
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Concentration"
        Me.ColumnHeader1.Width = 81
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Blank (deg)"
        Me.ColumnHeader2.Width = 76
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Sample (deg)"
        Me.ColumnHeader3.Width = 83
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "delta (deg)"
        Me.ColumnHeader4.Width = 78
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "Mean (deg)"
        Me.ColumnHeader6.Width = 85
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "Caculate Conc."
        Me.ColumnHeader5.Width = 104
        '
        'AxDynaPlot2
        '
        Me.AxDynaPlot2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.AxDynaPlot2.Location = New System.Drawing.Point(527, 24)
        Me.AxDynaPlot2.Name = "AxDynaPlot2"
        Me.AxDynaPlot2.OcxState = CType(resources.GetObject("AxDynaPlot2.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxDynaPlot2.Size = New System.Drawing.Size(380, 369)
        Me.AxDynaPlot2.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(945, 480)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Polarimeter"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.AxDynaPlot1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.AxDynaPlot2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveDataToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DevicesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConnectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DisconnectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ConfigAddressToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ScanIntensityToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StartToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StopToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents PauseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContinueToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents btnAddConc As System.Windows.Forms.Button
    Friend WithEvents AxDynaPlot1 As AxDYNAPLOT3Lib.AxDynaPlot
    Friend WithEvents btnRemoveConc As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtResolution As System.Windows.Forms.TextBox
    Friend WithEvents tvTreaments As System.Windows.Forms.TreeView
    Friend WithEvents btnRemoveScan As System.Windows.Forms.Button
    Friend WithEvents btnAddScan As System.Windows.Forms.Button
    Friend WithEvents btnPause As System.Windows.Forms.Button
    Friend WithEvents btnStop As System.Windows.Forms.Button
    Friend WithEvents btnStart As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents AxDynaPlot2 As AxDYNAPLOT3Lib.AxDynaPlot
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtStop As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtStart As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtDMMAddress As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents MMC2ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents txtMMCAddress As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents lblMinimumValue As System.Windows.Forms.Label
    Friend WithEvents chkDemo As System.Windows.Forms.CheckBox
    Friend WithEvents btnResetTreatment As System.Windows.Forms.Button
    Friend WithEvents lblSelectedNode As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents lblReport As System.Windows.Forms.Label
    Friend WithEvents btnCalculate As System.Windows.Forms.Button
    Friend WithEvents btnUpdateTable As System.Windows.Forms.Button

End Class
