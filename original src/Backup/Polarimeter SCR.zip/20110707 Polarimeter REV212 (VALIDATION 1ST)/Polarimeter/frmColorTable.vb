﻿Public Class frmColorTable

    Private Sub frmColorTable_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

    End Sub

    Private Sub frmColorTable_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        LoadColorTable()
    End Sub

    Private Sub LoadColorTable()
        lvColorTable.Items.Clear()
        Dim LVI As ListViewItem
        LVI = New ListViewItem
        LVI.UseItemStyleForSubItems = False
        LVI.Text = "Reference"
        LVI.SubItems.Add("")
        LVI.SubItems.Add(frmMain.ReferenceColor.ToString)
        LVI.SubItems(1).BackColor = frmMain.ReferenceColor
        For i As Integer = 0 To 19
            LVI = New ListViewItem
            LVI.UseItemStyleForSubItems = False
            LVI.Text = (i + 1).ToString
            LVI.SubItems.Add("")
            LVI.SubItems.Add(frmMain.ColorTable(i).ToString)
            LVI.SubItems(1).BackColor = frmMain.ColorTable(i)
        Next
    End Sub

    Private Sub ApplyColorTable()
        For i As Integer = 0 To 19
            frmMain.ColorTable(i) = lvColorTable.Items(i).SubItems(1).BackColor
        Next
    End Sub

    Private Sub lvColorTable_ItemSelectionChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.ListViewItemSelectionChangedEventArgs) Handles lvColorTable.ItemSelectionChanged
        MsgBox("hi2")
    End Sub

    Private Sub lvColorTable_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvColorTable.SelectedIndexChanged
        MsgBox("HI1")
    End Sub

End Class