﻿Imports System
Imports System.IO
Imports System.Text

Public Class frmMain

#Region "DECRALATION"

    'CONSTANTS
    Const StepFactor = 0.013325 'Deg/Step

    'Dynaplot objects
    Dim ReferenceCurve As DYNAPLOT3Lib.Curve
    Dim TreatmentCurve() As DYNAPLOT3Lib.Curve
    Dim TreatmentMinMarker As DYNAPLOT3Lib.Marker
    Dim ReferenceMinMarker As DYNAPLOT3Lib.Marker

    'SCANING & Data
    Dim TheData As BaseDataControl
    Dim IsScanning As Boolean = False
    Dim IsContinuing As Boolean = False
    Dim CurrentPointIndex As Integer = 0
    Dim SpecificRotation As Double
    Dim NumberOfRepeatation As Integer
    Dim SelectedIndex As Integer

#End Region

#Region "DEVICES"

    Private DMM As Ivi.Visa.Interop.IFormattedIO488
    Private MMC As Ivi.Visa.Interop.IFormattedIO488

#End Region

#Region "Control Panel"

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        'Add curve
        Dim x(0) As Double
        Dim y(0) As Double

        ResetDynaplot()

        PlotReferenceCurve()

        '----------------------------------------
        '1. Update buttons
        '----------------------------------------
        btnStart.Enabled = False
        btnStop.Enabled = True
        btnPause.Enabled = True

        '----------------------------------------
        'disable box
        '----------------------------------------
        gbSample.Enabled = False
        gbScanCondition.Enabled = False

        '----------------------------------------
        '2. start Test loop of reading light intensity
        '----------------------------------------
        CurrentPointIndex = 0
        IsScanning = True
        DoScanLightIntensity()

    End Sub

    Private Sub btnStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStop.Click
        '----------------------------------------
        '1. stop Test loop of reading light intensity
        '----------------------------------------
        StopScanning()

        '----------------------------------------
        '2. Update buttons
        '----------------------------------------
        btnStart.Enabled = True
        btnStop.Enabled = False
        btnPause.Enabled = False
        btnPause.Text = "PAUSE"

    End Sub

    Private Sub btnPause_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPause.Click
        '----------------------------------------
        '1. pause/continue Test loop of reading light intensity
        '----------------------------------------
        If btnPause.Text = "PAUSE" Then
            DoPauseScanning()
        Else
            DoContinueScanning()
        End If

        '----------------------------------------
        '2. Update buttons
        '----------------------------------------
        btnStart.Enabled = False
        btnStop.Enabled = True
        btnPause.Enabled = True
        If btnPause.Text = "PAUSE" Then
            btnPause.Text = "CONTINUE"
        Else
            btnPause.Text = "PAUSE"
            DoScanLightIntensity()
        End If
    End Sub

#End Region

#Region "Scanning Procedure"

    Private Sub DoScanLightIntensity()
        '--------------------------------------------
        'validate selected index of repeats
        '--------------------------------------------
        If lvSummary.SelectedItems.Count <= 0 Then
            MsgBox("Please select item in samples list view that you want to measure!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly)
            btnStart.Enabled = True
            btnStop.Enabled = False
            btnPause.Enabled = False
            btnPause.Text = "PAUSE"
            gbSample.Enabled = True
            gbScanCondition.Enabled = True
            Exit Sub
        End If

        If SelectedIndex = 0 Then
            If MsgBox("You going to measure the reference data. Would do you want to measure the reference?", MsgBoxStyle.YesNo) <> MsgBoxResult.Yes Then
                btnStart.Enabled = True
                btnStop.Enabled = False
                btnPause.Enabled = False
                btnPause.Text = "PAUSE"
                gbSample.Enabled = True
                gbScanCondition.Enabled = True
                Exit Sub
            End If
        End If
        
        If Not mnuOptionsDemomode.Checked Then
            ConnectDevices()
        End If

        Try
            '--------------------------------------------
            'get read conditions
            '--------------------------------------------
            Dim ThetaA As Double = CDbl(txtStart.Text)
            Dim ThetaB As Double = CDbl(txtStop.Text)
            Dim Delta As Double = CDbl(txtResolution.Text)

            '--------------------------------------------
            'initialize minimum finder
            '--------------------------------------------
            If Not IsContinuing Then
                If SelectedIndex = 0 Then
                    TheData.Reference.Ym = 99999999
                Else
                    If TheData.Data IsNot Nothing Then
                        If SelectedIndex <= TheData.Data.Length Then
                            TheData.Data(SelectedIndex - 1).Ym = 99999999
                        End If
                    End If
                End If
            End If

            '----------------------------------------------------------------
            'REAL INTERFACE YES OR NOT (Theta,I)
            '----------------------------------------------------------------
            Dim CurrentLightIntensity As Double
            Dim StepNumber As Integer
            Dim MSG As String
            Dim CurrentTheta As Double
            If ThetaA < ThetaB Then
                CurrentTheta = ThetaA + CurrentPointIndex * Delta
            ElseIf ThetaA > ThetaB Then
                CurrentTheta = ThetaA - CurrentPointIndex * Delta
            End If
            'check demo mode
            If mnuOptionsDemomode.Checked = False Then
                '0.4 GOTO Theta A
                StepNumber = -1 * CInt(CurrentTheta / StepFactor) 'step
                MSG = "A:XP" & StepNumber.ToString
                MMC.WriteString(MSG)
                '0.5 Read first
                DMM.WriteString("READ?")
                CurrentLightIntensity = DMM.ReadNumber
            Else 'IN DEMO MODE
                CurrentLightIntensity = Rnd() * 0.1 + Math.Cos((CurrentTheta - Rnd() * 50) * Math.PI / 180) + 2
            End If

            '----------------------------------------------------------------
            'STORE DATA AND PLOT
            '----------------------------------------------------------------
            'Save to memory
            If SelectedIndex = 0 Then 'Blank
                TheData.PatchReference(CurrentPointIndex, CurrentTheta, CurrentLightIntensity)
                ReferenceCurve.UpdateData(TheData.Reference.X, TheData.Reference.Y, CurrentPointIndex + 1)
                ReferenceMinMarker.PositionX = TheData.Reference.Xm
                ReferenceMinMarker.PositionY = TheData.Reference.Ym
                DefineAngleOfRotation()
            Else 'Treatments
                TheData.PatchData(SelectedIndex - 1, CurrentPointIndex, CurrentTheta, CurrentLightIntensity)
                TreatmentCurve(SelectedIndex - 1).UpdateData(TheData.Data(SelectedIndex - 1).X, TheData.Data(SelectedIndex - 1).Y, CurrentPointIndex + 1)
                TreatmentMinMarker.PositionX = TheData.Data(SelectedIndex - 1).Xm
                TreatmentMinMarker.PositionY = TheData.Data(SelectedIndex - 1).Ym
                DefineAngleOfRotation()
            End If


            '--------------------------------------------
            'MAIN READING LOOP (^0^)
            '--------------------------------------------
            While IsScanning

                Application.DoEvents()

                'Update current THETA
                If ThetaA < ThetaB Then
                    CurrentTheta = ThetaA + CurrentPointIndex * Delta
                ElseIf ThetaA > ThetaB Then
                    CurrentTheta = ThetaA - CurrentPointIndex * Delta
                End If

                '--------------------------------------------
                'CHECK DEMO MODE
                '--------------------------------------------
                If mnuOptionsDemomode.Checked = False Then

                    '--------------------------------------------
                    'REAL INTERFACING
                    '--------------------------------------------
                    '1. Move polarizer 
                    StepNumber = -1 * CInt(CurrentTheta / StepFactor) 'step
                    MSG = "A:XP" & StepNumber.ToString
                    MMC.WriteString(MSG)
                    '2. delay
                    Dim sw As New Stopwatch
                    sw.Start()
                    Do
                        'do nothing
                    Loop Until sw.ElapsedMilliseconds > 500 'ms
                    '3. Read light intensity
                    DMM.WriteString("READ?")
                    CurrentLightIntensity = DMM.ReadNumber

                Else

                    '--------------------------------------------
                    'DEMO MODE
                    '--------------------------------------------
                    'Delay.
                    Dim sw As New Stopwatch
                    sw.Start()
                    Do
                        'do nothing
                    Loop Until sw.ElapsedMilliseconds > 50 'ms
                    'Simulation
                    CurrentLightIntensity = Rnd() * 0.1 + Math.Cos((CurrentTheta - Rnd() * 50) * Math.PI / 180) + 2

                End If

                'Save to memory and update curve
                If SelectedIndex = 0 Then 'Blank
                    TheData.PatchReference(CurrentPointIndex, CurrentTheta, CurrentLightIntensity)
                    ReferenceCurve.UpdateData(TheData.Reference.X, TheData.Reference.Y, CurrentPointIndex + 1)
                    ReferenceMinMarker.PositionX = TheData.Reference.Xm
                    ReferenceMinMarker.PositionY = TheData.Reference.Ym
                    DefineAngleOfRotation()
                Else 'Treatments
                    TheData.PatchData(SelectedIndex - 1, CurrentPointIndex, CurrentTheta, CurrentLightIntensity)
                    TreatmentCurve(SelectedIndex - 1).UpdateData(TheData.Data(SelectedIndex - 1).X, TheData.Data(SelectedIndex - 1).Y, CurrentPointIndex + 1)
                    TreatmentMinMarker.PositionX = TheData.Data(SelectedIndex - 1).Xm
                    TreatmentMinMarker.PositionY = TheData.Data(SelectedIndex - 1).Ym
                    DefineAngleOfRotation()
                End If

                'auto scale
                AxDynaPlot1.Axes.Autoscale()

                'check stop condition!!!
                If ThetaA < ThetaB Then
                    If ThetaB < CurrentTheta Then IsScanning = False
                ElseIf ThetaA > ThetaB Then
                    If CurrentTheta < ThetaB Then IsScanning = False
                End If
                '--------------------------------------------

                'next point
                CurrentPointIndex += 1

            End While
            '--------------------------------------------(^0^)

            'if stop update buttons to a new start
            If btnPause.Text <> "CONTINUE" Then
                MSG = "A:XP" & CInt(-1 * ThetaA / StepFactor).ToString
                MMC.WriteString(MSG)
                DisconnectDevices()
                btnStart.Enabled = True
                btnStop.Enabled = False
                btnPause.Enabled = False
                btnPause.Text = "PAUSE"
                gbSample.Enabled = True
                gbScanCondition.Enabled = True
            Else 'if pause update buttons to continue
                DisconnectDevices()
                btnStart.Enabled = False
                btnStop.Enabled = True
                btnPause.Enabled = True
            End If

        Catch ex As Exception

            MsgBox(ex.Message)

            '----------------------------------------
            '1. stop Test loop of reading light intensity
            '----------------------------------------
            StopScanning()

            '----------------------------------------
            '2. Update buttons
            '----------------------------------------
            btnStart.Enabled = True
            btnStop.Enabled = False
            btnPause.Enabled = False
            btnPause.Text = "PAUSE"
            gbSample.Enabled = True
            gbScanCondition.Enabled = True

        End Try

    End Sub

    Private Sub StopScanning()
        IsScanning = False
        IsContinuing = False
    End Sub

    Private Sub DoPauseScanning()
        IsScanning = False
        IsContinuing = False
    End Sub

    Private Sub DoContinueScanning()
        IsScanning = True
        IsContinuing = True
    End Sub

#End Region

#Region "Menus"

#Region "File"

    Private Sub mnuFileNewMeasurement_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileNewMeasurement.Click
        NewMeasurement()
    End Sub

    Private Sub mnuFileLoadMC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub mnuFileSaveDataAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileSaveDataAs.Click

    End Sub

    Private Sub mnuFileSaveMC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub mnuSaveMCAs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub mnuFileOpendata_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileOpendata.Click

    End Sub

    Private Sub mnuFileSaveData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileSaveData.Click
        TheData.SaveFile()
    End Sub

    Private Sub mnuFileQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileQuit.Click
        Close()
    End Sub

#End Region


    Private Sub ConnectToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConnectToolStripMenuItem.Click
        ConnectDevices()
    End Sub

    Private Sub DisconnectToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisconnectToolStripMenuItem.Click
        DisconnectDevices()
    End Sub

#End Region

#Region "Form Event"

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        IsScanning = False
    End Sub

#End Region

#Region "PLOT when select curve"

    Private Sub ResetDynaplot()
        Dim x(0) As Double
        Dim y(0) As Double

        AxDynaPlot1.DataCurves.RemoveAll()
        AxDynaPlot1.Markers.RemoveAll()

        ReferenceCurve = AxDynaPlot1.DataCurves.Add("REF", x, y, 0, False).Curve
        ReferenceMinMarker = AxDynaPlot1.Markers.Add(0.0, 0.0, 0, DYNAPLOT3Lib.dpsMARKERTYPE.dpsMARKER_CIRCLE)

        For i As Integer = 0 To NumberOfRepeatation - 1
            TreatmentCurve(i) = AxDynaPlot1.DataCurves.Add("TRT" & i.ToString, x, y, 0, False).Curve
        Next
        TreatmentMinMarker = AxDynaPlot1.Markers.Add(0.0, 0.0, 0, DYNAPLOT3Lib.dpsMARKERTYPE.dpsMARKER_SQUARE)

    End Sub

    Private Function PlotReferenceCurve() As Boolean
        Dim e As Boolean = False
        If TheData.Reference.X IsNot Nothing Then
            ReferenceCurve.UpdateData(TheData.Reference.X, TheData.Reference.Y, TheData.Reference.X.Length)
            ReferenceMinMarker.PositionX = TheData.Reference.Xm
            ReferenceMinMarker.PositionY = TheData.Reference.Ym
            lblNullPoint.Text = TheData.Reference.Xm.ToString("0.0000") & " deg"
            AxDynaPlot1.Axes.Autoscale()
            e = True
        End If
        Return e
    End Function

    Private Function PlotSelectedTreatmentCurve() As Boolean
        If TheData Is Nothing Then Return False
        If TheData.Data Is Nothing Then Return False
        For i As Integer = 0 To NumberOfRepeatation - 1
            Try
                TreatmentCurve(i).UpdateData(TheData.Data(i).X, _
                                          TheData.Data(i).Y, _
                                          TheData.Data(i).X.Length)
            Catch ex As Exception
                Err.Clear()
            End Try
        Next
        AxDynaPlot1.Axes.Autoscale()
        Try
            TreatmentMinMarker.PositionX = TheData.Data(SelectedIndex - 1).Xm
            TreatmentMinMarker.PositionY = TheData.Data(SelectedIndex - 1).Ym
            lblNullPoint.Text = TheData.Data(SelectedIndex - 1).Xm.ToString("0.0000") & " deg"
        Catch ex As Exception
            Err.Clear()
        End Try
        Return True
    End Function

#End Region

#Region "Sub-Routine"

    Private Sub DisconnectDevices()
        Try
            DMM.IO.Close()
            DMM.IO = Nothing
            MMC.IO.Close()
            MMC.IO = Nothing
            'MsgBox("Devices have been disconnected.")

        Catch ex As Exception
            MsgBox("IO Error: " & ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub ConnectDevices()

        Try
            '-------------------------------------------
            'CONNECT DMM
            '-------------------------------------------
            Dim mgr1 As Ivi.Visa.Interop.ResourceManager
            Dim DMMAddress As String
            DMMAddress = txtDMMAddress.Text
            mgr1 = New Ivi.Visa.Interop.ResourceManager
            DMM = New Ivi.Visa.Interop.FormattedIO488
            DMM.IO() = mgr1.Open(DMMAddress)
            DMM.IO.Timeout = 7000

            '-------------------------------------------
            'CONNECT MMC
            '-------------------------------------------
            Dim mgr2 As Ivi.Visa.Interop.ResourceManager
            Dim MMCAddress As String
            MMCAddress = txtMMCAddress.Text
            mgr2 = New Ivi.Visa.Interop.ResourceManager
            MMC = New Ivi.Visa.Interop.FormattedIO488
            MMC.IO() = mgr2.Open(MMCAddress)
            MMC.IO.Timeout = 7000

            'MsgBox("Connect devices are successful.")

        Catch ex As Exception
            MsgBox("InitIO Error:" & vbCrLf & ex.Message)
        End Try

    End Sub

    Private Sub NewMeasurement()
        'load dialog
        Dim f As New frmNewMeasurement
        f.StartPosition = FormStartPosition.CenterScreen
        f.ShowDialog()

        'do update the job
        If f.Verify() = True Then

            'get information
            txtSampleName.Text = f.SampleName
            NumberOfRepeatation = f.NumberOfRepeatation

            'initialize the data object
            TheData = New BaseDataControl
            TheData.SampleName = txtSampleName.Text
            TheData.SpecificRotation = SpecificRotation

            'clear
            lvSummary.Items.Clear()
            Dim lvi As ListViewItem

            'add ref.
            lvi = New ListViewItem
            lvi.Text = "Reference"
            lvi.SubItems.Add("-")
            lvi.SubItems.Add("-")
            lvi.SubItems.Add("-")
            lvSummary.Items.Add(lvi)

            'add repeats
            For i As Integer = 1 To NumberOfRepeatation
                lvi = New ListViewItem
                lvi.Text = "Repeat " & i.ToString
                lvi.SubItems.Add("-")
                lvi.SubItems.Add("-")
                lvi.SubItems.Add("-")
                lvSummary.Items.Add(lvi)
            Next

            'clear treatment curve
            ReDim TreatmentCurve(0 To NumberOfRepeatation - 1)

            gbMeasurement.Enabled = True
            gbSample.Enabled = True
            gbScanCondition.Enabled = True
        End If
    End Sub

    Private Sub DefineAngleOfRotation()
        Dim lvi As ListViewItem
        lvi = lvSummary.Items(SelectedIndex)
        If SelectedIndex = 0 Then
            lvi.SubItems(1).Text = _
                "(" & _
                TheData.Reference.Xm.ToString("0.00") & _
                ", " & _
                TheData.Reference.Ym.ToString("0.00") & _
                ")"
        Else
            lvi = lvSummary.Items(SelectedIndex)
            lvi.SubItems(1).Text = _
                "(" & _
                TheData.Data(SelectedIndex - 1).Xm.ToString("0.00") & _
                ", " & _
                TheData.Data(SelectedIndex - 1).Ym.ToString("0.00") & _
                ")"
            lvi.SubItems(2).Text = TheData.Data(SelectedIndex - 1).AngleOfRotation.ToString("0.00")
            lvi.SubItems(3).Text = TheData.Data(SelectedIndex - 1).Concentration.ToString("0.00")
        End If
    End Sub

#End Region

#Region "Summary"

    Private Sub lvSummary_ItemSelectionChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.ListViewItemSelectionChangedEventArgs) Handles lvSummary.ItemSelectionChanged
        If lvSummary.SelectedIndices Is Nothing Then Exit Sub
        If lvSummary.SelectedIndices.Count <= 0 Then Exit Sub
        SelectedIndex = lvSummary.SelectedIndices(0)
        Try
            If SelectedIndex = 0 Then
                lblSample.Text = "Reference"
            Else
                lblSample.Text = "Repeat " & SelectedIndex.ToString
            End If
            ResetDynaplot()
            PlotReferenceCurve()
            PlotSelectedTreatmentCurve()
        Catch ex As Exception
            'do nothing
        End Try
    End Sub

#End Region
    

    Private Sub btnINIT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnINIT.Click
        Try
            ConnectDevices()
            Dim MSG As String = "A:XP" & CInt(-1 * Val(txtStart.Text) / StepFactor).ToString
            MMC.WriteString(MSG)
            DisconnectDevices()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        NewMeasurement()
    End Sub
End Class
