Win32 Visual Basic Language Interface

This directory contains the following:

     README.TXT          -  This readme file
     NIGLOBAL.BAS        -  Visual Basic global module containing
                            certain predefined constant declarations
     VBIB-32.BAS         -  Visual Basic source file with NI-488.2
                            routine and function prototypes
     <subdirectories>    -  Contain different sample applications


The sample applications help you learn how to use the NI-488.2 API. You
can use these applications as starting points for your applications.

The sample applications were created using Microsoft Visual Basic 6.0.
If you have Microsoft Visual Basic 5.0 or lower, there are sample 
applications available on the Web. Please refer to the Example Code in 
the Support section at the following location:

      http://www.ni.com/gpib/



Copyright National Instruments Corporation.
All Rights Reserved.


