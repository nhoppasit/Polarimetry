Win32 Visual Basic SERIALPOLL Sample Application

This directory contains the following:

     README.TXT            -  This readme file
     SERIALPOLL.VBP        -  Visual Basic project file
     SERIALPOLL.FRM        -  Visual Basic form file



Description
-----------

The SerialPoll sample application was written to acquire measurements
from a Tektronix TDS 210 Two Channel Digital Real-Time Oscilloscope.
The application is a Win32 GUI application that was created using
Microsoft Visual Basic 6.0. It illustrates how to use the NI-488.2 API.

The sample applications were created using Microsoft Visual Basic 6.0.
If you have Microsoft Visual Basic 5.0 or lower, there are sample 
applications available on the Web. Please refer to the Example Code in 
the Support section at the following location:

      http://www.ni.com/gpib/


Checking Status with Global Variables
-------------------------------------

Each NI-488.2 call updates four global variables to reflect the status
of the device or board that you are using. The four global variables
are the status word (ibsta), the error variable (iberr), and the
count variables (ibcnt and ibcntl). Your application should check for
errors after each NI-488.2 call by looking at ibsta. The ERR bit in
ibsta indicates if the call succeeded or not. If the ERR bit is set,
iberr contains an error code. For a complete description of ibsta
bits and iberr error codes, see the online help. If you are writing a
multithreaded application, please refer to the online help on writing
multithreaded applications.


Compiling, Linking, and Running the Sample Application
------------------------------------------------------

To open the sample application, select OPEN PROJECT... from the FILE
menu. In the OPEN PROJECT dialog box, click on SERIALPOLL.VBP to
highlight it, and then click on the OPEN button.

To compile the project and link it to the Visual Basic language
interface, VBIB-32.BAS, select the MAKE SERIALPOLL.EXE... item from
the FILE menu.

To run the project, select the START item from the RUN menu.


More Information
----------------

Refer to the NI-488.2 online help for more information on application
development.



Copyright National Instruments Corporation.
All Rights Reserved.
