Win32 Visual Basic Sample Applications for ibnotify

This directory contains the following:

    README.TXT      -  This readme file
    NOTIFY.BAS      -  Visual Basic global module containing ibnotify
                       function prototype
    CALLBACK.BAS    -  Visual Basic NI-488.2 callback function for the
                       NTFYSAMP project
    NTFYSAMP.MAK    -  Visual Basic NI-488.2 ibnotify sample
                       application make file
    NTFYSAMP.FRM    -  Visual Basic NI-488.2 ibnotify sample
                       application form file
    OCXSAMP.MAK     -  Visual Basic GPIB OLE Control sample
                       application make file
    OCXSAMP.FRM     -  Visual Basic GPIB OLE Control sample
                       application form file


Description
-----------

These sample applications were written to acquire measurements from a
Fluke 45 Digital Multimeter. The applications are Win32 GUI
applications that were created using the Microsoft Visual Basic 6.0.
They illustrate how to use asynchronous event notification.

The sample applications were created using Microsoft Visual Basic 6.0.
If you have Microsoft Visual Basic 5.0 or lower, there are sample 
applications available on the Web. Please refer to the Example Code in 
the Support section at the following location:

      http://www.ni.com/gpib/


Asynchronous Event Notification Overview
----------------------------------------

Win32 NI-488.2 applications can asynchronously receive event
notifications using the ibnotify function. This function is useful if
you want your application to be notified asynchronously about the
occurrence of one or more NI-488.2 events. An NI-488.2 application
using ibnotify consists of three basic pieces- a mask initialized
with the desired NI-488.2 events, the ibnotify function call, and a
user-defined callback function. The user-defined callback function
that you register with the ibnotify function is invoked by the
NI-488.2 driver when one or more of the NI-488.2 event masks bits
passed to it is TRUE. In the sample applications, when the RQS bit is
set, the callback is invoked. The callback proceeds to get the
measurements from the Fluke 45.

For asynchronous event notification, you can use either one of two
methods. The first method uses the AddressOf operator (supported in
Visual Basic 6.0) to pass the address of the user-defined callback 
function to the ibnotify function. For more information, please refer 
to section called USING IBNOTIFY WITH THE ADDRESSOF OPERATOR. The 
NTFYSAMP project illustrates how to use the AddressOf operator when 
calling ibnotify. The second method uses the GpibNotify OLE Control. 
For more information, please refer to the section called USING THE 
GPIBNOTIFY OLE CONTROL. The OCXSAMP project illustrates how to use 
the GpibNotify OLE Control.


Using ibnotify with the ADDRESSOF Operator
------------------------------------------

   This section covers the key items needed for an NI-488.2 application
   that uses the ibnotify function. Below is list of the key modules.

      CALLBACK.BAS - Visual Basic module containing a user-defined
                     callback function. In the sample project, it also
                     contains a few globally declared variables that
                     are used in the NTFYSAMP project. The callback
                     in this sample project reads in measurements from
                     the Fluke 45.

      NOTIFY.BAS   - Visual Basic NI-488.2 module containing the
                     ibnotify function prototype

      NTFYSAMP.FRM - Visual Basic NI-488.2 ibnotify sample form
                     containing the code that initializes the Fluke
                     45, calls the ibnotify function, and prints the
                     data to the screen.

   When creating a Win32 NI-488.2 application that calls the ibnotify
   function, you need to use the AddressOf operator in order to pass
   the address of the user-defined callback function to ibnotify. In
   this sample application, when the RQS bit is set, the callback,
   called DevCallback, is invoked.

   With Visual Basic, you can access the NI-488.2 functions as
   subroutines, using the BASIC keyword CALL followed by the function
   name, or you can access the NI-488.2 function using the il set of
   functions. In this README file, the ibnotify/ilnotify function is
   referred to as ibnotify. However, the NTFYSAMP sample application
   uses the ilnotify function. Below is a code fragment illustrating
   how to call ibnotify using the ilnotify function with the RQS mask,
   the AddressOf operator, and the user-defined reference data.

   ilnotify Dev, RQS, AddressOf DevCallback, RefData

   For more information about the usage of ibnotify, please refer to
   the online help on writing Asynchronous Event Notification
   applications. For more information about the AddressOf operator,
   please refer to the online help that comes with Visual Basic 6.0.

   Compiling, Linking, and Running the Sample Application
   ------------------------------------------------------

   To open the sample application, select OPEN PROJECT... from
   the FILE menu. In the OPEN PROJECT dialog box, click on
   NTFYSAMP.MAK to highlight it, and then click on the OPEN button.

   To compile the project and link it to the Visual Basic language
   interface, VBIB-32.BAS, select the MAKE NTFYSAMP.EXE... item from
   the FILE menu.

   To run the project, select the START item from the RUN menu.

   Creating Your Own NI-488.2 Application Using ibnotify
   -----------------------------------------------------

   This section describes the items that you need to add to your
   Visual Basic project. For more detailed information about how to
   create a Visual Basic project and how to add buttons and such to
   the form, please refer to the online help that comes with Visual
   Basic.

   You must include NOTIFY.BAS, VBIB-32.BAS, and NIGLOBAL.BAS in your
   Microsoft Visual Basic (version 6.0) application project file. 
   NOTIFY.BAS contains the ibnotify function prototype. VBIB-32.BAS 
   contains the NI-488.2 function prototypes for interfacing with the 
   dynamic link library GPIB-32.DLL. NIGLOBAL.BAS contains NI-488.2-
   specific variable declarations and constant definitions.

   The user-defined callback cannot be placed inside the form module.
   In the NTFYSAMP project, a separate .BAS module, CALLBACK.BAS,
   contains the callback function called DevCallback.

   Odd Behavior Caused by Modal Dialog Boxes
   -----------------------------------------

   Our testing uncovered the following odd behavior in Visual Basic:
   if an application creates a modal dialog box (like the one created
   by MsgBox), within the user-defined callback, the callback gets
   mysteriously lost. Because of this, we decided to avoid modal
   dialog boxes in our Visual Basic sample application that uses the
   ibnotify function and the user-defined callback.


Using the GpibNotify OLE Control
--------------------------------

   This section first describes the OCXSAMP project and then it
   describes how to add the GpibNotify OLE Control to an application.

   The OCXSAMP project illustrates how you might use the GpibNotify
   OLE Control in your NI-488.2 application. The OCXSAMP.FRM contains
   the code that gets the ten measurements from the Fluke 45. When the
   RUN button is clicked, it invokes the RunTest() subroutine.
   RunTest() illustrates how to initialize the mask for the desired
   NI-488.2 events and how to call the GpibNotify1.SetupNotify
   function which invokes the notify method.

   To view the code used for the callback routine for this particular
   application, please refer to the subroutine called:

   Private Sub GpibNotify1_Notify()

   Compiling, Linking, and Running the Sample Application
   ------------------------------------------------------

   To open the sample application, select OPEN PROJECT... from
   the FILE menu. In the OPEN PROJECT dialog box, click on OCXSAMP.MAK
   to highlight it, and then click on the OPEN button.

   To compile the project and link it to the Visual Basic language
   interface, VBIB-32.BAS, select the MAKE OCXSAMP.EXE... item from
   the FILE menu.

   To run the project, select the START item from the RUN menu.

   Adding the GpibNotify OLE Control to a Project
   ------------------------------------------------

   This section describes the items that you need to add to your own
   Visual Basic project. For more detailed information about how to
   create a Visual Basic project and how to add buttons and such to
   the form, please refer to the online help that comes with Visual
   Basic.

   You must include VBIB-32.BAS and NIGLOBAL.BAS in your Microsoft
   Visual Basic (version 6.0) application project file. VBIB-32.BAS 
   contains the NI-488.2 function prototypes for interfacing with the 
   dynamic link library GPIB-32.DLL. NIGLOBAL.BAS contains NI-488.2-
   specific variable declarations and constant definitions.

   To add the GpibNotify OLE control to your application's toolbar,
   follow the steps below:

   1. Select COMPONENTS from the PROJECT menu.
   2. In the COMPONENTS dialog box that appears, put an 'X' in
      the box to the left of the GPIBNOTIFY OLE CONTROL MODULE by
      clicking on the box itself. Click OK.
   3. An icon is added to your TOOLBOX. It has a picture of a bell
      labeled "NOTIFY".

   For each GpibNotify OLE control that you want to add, follow the
   instructions in this section:

   1. To add the GpibNotify OLE control to your form, double-click on
      the NOTIFY icon. This places the "GPIB notify" icon onto your
      form.
   2. To add code to the callback routine, double-click on the GPIB
      notify icon. The callback routine is named GpibNotifyX_Notify
      where X is the particular numbered GpibNotify Control. Each
      GpibNotify OLE control is numbered. The first control is
      numbered 1, the next control is numbered 2, and so on.

   There are three different methods that you can use to initialize
   the SetupMask for the desired NI-488.2 events for the SetupNotify
   function.

   METHOD 1:

   One method is to assign a SetupMask value to the SetupNotify
   function by declaring an integer value and setting it to the
   desired NI-488.2 event(s) as shown below:

   Dim mask As Integer
   mask = XXX           ' Set mask for the desired NI-488.2 event(s).

   where XXX is the desired NI-488.2 event(s) (for example, CMPL, RQS,
   TIMO) that you wish to invoke the callback with. The call to
   SetupNotify would look like this:

   GpibNotifyX.SetupNotify ud, mask

   where X is for the particular numbered control that you wish to
   invoke and ud is the unit descriptor that was obtained using either
   ibdev or ibfind. You can override the GpibNotify Control Properties
   page's setting by calling the SetupNotify function and passing in
   the mask value as the second parameter.

   METHOD 2:

   Another method is to modify the GpibNotify Control Properties page.
   To access that page, follow the steps below:

   1. Right-click on the GpibNotify icon as it appears on your form.
   2. Select PROPERTIES... from the drop-down list.
   3. In the PROPERTY PAGES dialog box, click on the box to the left
      of the NI-488.2 event for each and every NI-488.2 event that you
      wish to monitor.
   4. When you have finished selecting all the desired NI-488.2 events,
      click OK.

   Then to call the SetupNotify, add the following line of code:

   GpibNotifyX.SetupNotify ud

   where X is for the particular numbered control that you wish to
   invoke and ud is the unit descriptor that was obtained using either
   ibdev or ibfind.

   METHOD 3:

   The third method is to initialize the SetupMask for the desired
   NI-488.2 event, as shown below:

   GpibNotifyX.SetupMask = RQS

   Then you can call the SetupNotify function like so:

   GpibNotifyX.SetupNotify ud

   where X is for the particular numbered control that you wish to
   invoke and ud is the unit descriptor that was obtained using either
   ibdev or ibfind.

   Checking the NI-488.2 Global Variables After SetupNotify
   --------------------------------------------------------

   After you make a SetupNotify call, the global NI-488.2 status
   variables (ibsta, iberr, ibcnt, and ibcntl) are undefined. Instead,
   use the thread-specific NI-488.2 status variable functions
   (ThreadIbsta(), ThreadIberr(), ThreadIbcnt(), and ThreadIbcntl(),
   to examine the NI-488.2 status variables returned by the SetupNotify
   call. This restriction only applies to the SetupNotify call; for the
   rest of the NI-488.2 calls, you can continue to examine ibsta,
   iberr, ibcnt, and ibcntl.

   Odd Behavior Caused by Modal Dialog Boxes
   -----------------------------------------

   Our testing uncovered the following odd behavior in Visual Basic:
   if an application creates a modal dialog box (like the one created
   by MsgBox), the Notify callback gets mysteriously lost and never
   occurs. Because of this, we decided to avoid modal dialog boxes in
   our Visual Basic sample application that uses the GpibNotify OLE
   control.



Copyright National Instruments Corporation.
All Rights Reserved.

