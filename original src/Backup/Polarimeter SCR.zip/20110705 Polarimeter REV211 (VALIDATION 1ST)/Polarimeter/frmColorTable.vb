﻿Public Class frmColorTable

    Private Sub frmColorTable_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        lvColorTable.Items.Clear()
        For i As Integer = 0 To 19
            Dim LVI As New ListViewItem
            LVI.UseItemStyleForSubItems = False
            LVI.Text = (i + 1).ToString
            LVI.SubItems.Add("")
            LVI.SubItems.Add(frmMain.ColorTable(i).ToString)
            LVI.SubItems(1).BackColor = frmMain.ColorTable(i)
        Next
    End Sub

End Class