﻿Public Class Form1

#Region "DECRALATION"

    'Structure
    Structure strucData
        Dim X() As Double
        Dim Y() As Double
    End Structure
    Structure strucTreatment
        Dim Repreat() As strucData

    End Structure

    '******MAIN PRIMARY INFORMATION*************
    Dim Blank As strucTreatment
    Dim Treatments() As strucTreatment
    Dim MyCurve As DYNAPLOT3Lib.Curve
    '*******************************************

    'CONSTANTS
    Const StepFactor = 0.013325 'Deg/Step

    'SCAN PROCECURE
    Dim IsScanning As Boolean = False
    Dim CurrentPointIndex As Integer = 0

#End Region

#Region "DEVICES"

    Private DMM As Ivi.Visa.Interop.IFormattedIO488
    Private MMC As Ivi.Visa.Interop.IFormattedIO488

#End Region

#Region "Control Panel"

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        'Add curve
        Dim x(0) As Double
        Dim y(0) As Double
        AxDynaPlot1.DataCurves.RemoveAll()
        MyCurve = AxDynaPlot1.DataCurves.Add("+", x, y, 0, False).Curve

        '----------------------------------------
        '1. Update buttons
        '----------------------------------------
        btnStart.Enabled = False
        btnStop.Enabled = True
        btnPause.Enabled = True

        '----------------------------------------
        '2. start Test loop of reading light intensity
        '----------------------------------------
        CurrentPointIndex = 0
        IsScanning = True
        DoScanLightIntensity()

    End Sub

    Private Sub btnStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStop.Click
        '----------------------------------------
        '1. stop Test loop of reading light intensity
        '----------------------------------------
        StopScanning()

        '----------------------------------------
        '2. Update buttons
        '----------------------------------------
        btnStart.Enabled = True
        btnStop.Enabled = False
        btnPause.Enabled = False
        btnPause.Text = "PAUSE"

    End Sub

    Private Sub btnPause_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPause.Click
        '----------------------------------------
        '1. pause/continue Test loop of reading light intensity
        '----------------------------------------
        If btnPause.Text = "PAUSE" Then
            DoPauseScanning()
        Else
            DoContinueScanning()
        End If

        '----------------------------------------
        '2. Update buttons
        '----------------------------------------
        btnStart.Enabled = False
        btnStop.Enabled = True
        btnPause.Enabled = True
        If btnPause.Text = "PAUSE" Then
            btnPause.Text = "CONTINUE"
        Else
            btnPause.Text = "PAUSE"
            DoScanLightIntensity()
        End If

    End Sub

#End Region

#Region "Scanning Procedure"

    Private Sub DoScanLightIntensity()
        Try
            '0.1 Get node id
            Dim i As Integer = TreeView1.SelectedNode.Parent.Index
            Dim j As Integer = TreeView1.SelectedNode.Index

            '0.2 Redimension Treatments
            If i = 0 Then 'Blank
                ReDim Preserve Blank.Repreat(0 To j)
            Else 'Treatments
                ReDim Preserve Treatments(0 To i)
                ReDim Preserve Treatments(i).Repreat(0 To j)
            End If

            '0.3 Read conditions
            Dim ThetaA As Double = CDbl(txtStart.Text)
            Dim ThetaB As Double = CDbl(txtStop.Text)
            Dim Delta As Double = CDbl(txtResolution.Text)

            '0.4 GOTO Theta A
            Dim StepNumber As Integer = CInt(ThetaA / StepFactor) 'step
            Dim MSG As String = "A:XP-" & StepNumber.ToString
            MMC.WriteString(MSG)

            '0.5 Read first
            DMM.WriteString("READ?")
            Dim CurrentLightIntensity As Double = DMM.ReadNumber

            '0.6 Save to memory
            If i = 0 Then 'Blank
                ReDim Preserve Blank.Repreat(j).X(0 To CurrentPointIndex)
                ReDim Preserve Blank.Repreat(j).Y(0 To CurrentPointIndex)
                Blank.Repreat(j).X(CurrentPointIndex) = ThetaA
                Blank.Repreat(j).Y(CurrentPointIndex) = CurrentLightIntensity
                MyCurve.UpdateData(Blank.Repreat(j).X, Blank.Repreat(j).Y, CurrentPointIndex)
            Else 'Treatments
                ReDim Preserve Treatments(i).Repreat(j).X(0 To CurrentPointIndex)
                ReDim Preserve Treatments(i).Repreat(j).Y(0 To CurrentPointIndex)
                Treatments(i).Repreat(j).X(CurrentPointIndex) = ThetaA
                Treatments(i).Repreat(j).Y(CurrentPointIndex) = CurrentLightIntensity
                MyCurve.UpdateData(Treatments(i).Repreat(j).X, Treatments(i).Repreat(j).Y, CurrentPointIndex)
            End If


            '**Read Loop*************************
            While IsScanning

                Application.DoEvents()

                'Update point index
                CurrentPointIndex += 1

                '1. Move polarizer 
                Dim CurrentTheta As Double = ThetaA + CurrentPointIndex * Delta
                StepNumber = CInt(CurrentTheta / StepFactor) 'step
                MSG = "A:XP-" & StepNumber.ToString
                MMC.WriteString(MSG)

                'delay
                Dim sw As New Stopwatch
                sw.Start()
                Do
                    'do nothing
                Loop Until sw.ElapsedMilliseconds > 500 'ms

                '2. Read light intensity
                DMM.WriteString("READ?")
                CurrentLightIntensity = DMM.ReadNumber

                '3. Save to memory
                If i = 0 Then 'Blank
                    ReDim Preserve Blank.Repreat(j).X(0 To CurrentPointIndex)
                    ReDim Preserve Blank.Repreat(j).Y(0 To CurrentPointIndex)
                    Blank.Repreat(j).X(CurrentPointIndex) = CurrentTheta
                    Blank.Repreat(j).Y(CurrentPointIndex) = CurrentLightIntensity
                    MyCurve.UpdateData(Blank.Repreat(j).X, Blank.Repreat(j).Y, CurrentPointIndex)
                Else 'Treatments
                    ReDim Preserve Treatments(i).Repreat(j).X(0 To CurrentPointIndex)
                    ReDim Preserve Treatments(i).Repreat(j).Y(0 To CurrentPointIndex)
                    Treatments(i).Repreat(j).X(CurrentPointIndex) = CurrentTheta
                    Treatments(i).Repreat(j).Y(CurrentPointIndex) = CurrentLightIntensity
                    MyCurve.UpdateData(Treatments(i).Repreat(j).X, Treatments(i).Repreat(j).Y, CurrentPointIndex)
                End If
                AxDynaPlot1.Axes.Autoscale()

                'check stop condition
                If ThetaB < CurrentTheta Then IsScanning = False

            End While

            'update buttons
            btnStart.Enabled = True
            btnStop.Enabled = False
            btnPause.Enabled = False
            btnPause.Text = "PAUSE"

        Catch ex As Exception

            MsgBox(ex.Message)

            '----------------------------------------
            '1. stop Test loop of reading light intensity
            '----------------------------------------
            StopScanning()

            '----------------------------------------
            '2. Update buttons
            '----------------------------------------
            btnStart.Enabled = True
            btnStop.Enabled = False
            btnPause.Enabled = False
            btnPause.Text = "PAUSE"

        End Try

    End Sub

    Private Sub StopScanning()
        IsScanning = False
    End Sub

    Private Sub DoPauseScanning()
        IsScanning = False
    End Sub

    Private Sub DoContinueScanning()
        IsScanning = True
    End Sub

#End Region

#Region "Menus"

    Private Sub ConnectToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConnectToolStripMenuItem.Click

        Try
            '-------------------------------------------
            'CONNECT DMM
            '-------------------------------------------
            Dim mgr1 As Ivi.Visa.Interop.ResourceManager
            Dim DMMAddress As String
            DMMAddress = txtDMMAddress.Text
            mgr1 = New Ivi.Visa.Interop.ResourceManager
            DMM = New Ivi.Visa.Interop.FormattedIO488
            DMM.IO() = mgr1.Open(DMMAddress)
            DMM.IO.Timeout = 7000

            '-------------------------------------------
            'CONNECT MMC
            '-------------------------------------------
            Dim mgr2 As Ivi.Visa.Interop.ResourceManager
            Dim MMCAddress As String
            MMCAddress = txtMMCAddress.Text
            mgr2 = New Ivi.Visa.Interop.ResourceManager
            MMC = New Ivi.Visa.Interop.FormattedIO488
            MMC.IO() = mgr2.Open(MMCAddress)
            MMC.IO.Timeout = 7000

            MsgBox("Connect devices are successful.")

        Catch ex As Exception
            MsgBox("InitIO Error:" & vbCrLf & ex.Message)
        End Try

    End Sub

    Private Sub DisconnectToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisconnectToolStripMenuItem.Click
        Try

            DMM.IO.Close()
            DMM.IO = Nothing
            MMC.IO.Close()
            MMC.IO = Nothing
            MsgBox("Devices have been disconnected.")

        Catch ex As Exception
            MsgBox("IO Error: " & ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

#End Region

#Region "Form Event"

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        IsScanning = False
    End Sub

#End Region

End Class
